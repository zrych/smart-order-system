<?php
// classes/MLModel.php
require_once __DIR__ . '/../vendor/autoload.php';

use Sentiment\Analyzer;

/**
 * MLModel — Order Prediction Engine
 *
 * Chosen ML Feature (PT #3, Sample Feature #2):
 *   "Predict if a customer will order again."
 *
 * Required OOP methods:
 *   preprocessData()  — extracts & normalises features from MySQL
 *   trainModel()      — derives thresholds from the data distribution
 *   predict($task)    — runs a prediction task and returns results
 *
 * Packagist package used for supporting analysis:
 *   davmixcool/php-sentiment-analyzer (VADER)
 */
class MLModel
{
    private $conn;
    private $analyzer;
    private $processedData = [];
    private $thresholds    = [];

    // Feature weights for the prediction model (must sum to 1.0)
    private const WEIGHTS = [
        'frequency'  => 0.30,
        'loyalty'    => 0.25,
        'recency'    => 0.25,
        'spend'      => 0.15,
        'cancel_pen' => 0.05,
    ];

    public function __construct($db)
    {
        $this->conn     = $db;
        $this->analyzer = new Analyzer();
    }

    // ─────────────────────────────────────────────────────────
    //  preprocessData()
    //  Pulls every feature needed for prediction from the DB.
    // ─────────────────────────────────────────────────────────
    public function preprocessData(): array
    {
        $stmt = $this->conn->query("
            SELECT
                c.id,
                c.name,
                c.email,
                COUNT(o.id)                                              AS order_count,
                COALESCE(SUM(o.quantity * o.price), 0)                   AS total_spent,
                COALESCE(AVG(o.quantity * o.price), 0)                   AS avg_order_value,
                MAX(o.created_at)                                        AS last_order_date,
                MIN(o.created_at)                                        AS first_order_date,
                SUM(CASE WHEN o.status = 'completed'  THEN 1 ELSE 0 END) AS completed_orders,
                SUM(CASE WHEN o.status = 'cancelled'  THEN 1 ELSE 0 END) AS cancelled_orders,
                SUM(CASE WHEN o.status = 'pending'    THEN 1 ELSE 0 END) AS pending_orders,
                SUM(CASE WHEN o.status = 'processing' THEN 1 ELSE 0 END) AS processing_orders
            FROM customers c
            LEFT JOIN orders o ON c.id = o.customer_id
            GROUP BY c.id, c.name, c.email
        ");
        $customers = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Order notes for sentiment analysis (Packagist feature)
        $stmt2 = $this->conn->query("
            SELECT o.id, o.notes, o.product, o.status,
                   c.name AS customer_name, c.id AS customer_id
            FROM orders o
            JOIN customers c ON o.customer_id = c.id
            WHERE o.notes IS NOT NULL AND TRIM(o.notes) != ''
            ORDER BY o.created_at DESC
        ");
        $notes = $stmt2->fetchAll(PDO::FETCH_ASSOC);

        $this->processedData = compact('customers', 'notes');
        return $this->processedData;
    }

    // ─────────────────────────────────────────────────────────
    //  trainModel()
    //  Derives statistical thresholds from the dataset so the
    //  model self-calibrates regardless of data size.
    // ─────────────────────────────────────────────────────────
    public function trainModel(): array
    {
        if (empty($this->processedData)) $this->preprocessData();

        $customers = $this->processedData['customers'];

        if (empty($customers)) {
            $this->thresholds = [
                'max_orders'     => 5,
                'max_spend'      => 10000,
                'recency_warm'   => 60,
                'recency_cold'   => 180,
            ];
            return $this->thresholds;
        }

        $orderCounts = array_map('intval',   array_column($customers, 'order_count'));
        $spends      = array_map('floatval', array_column($customers, 'total_spent'));

        $this->thresholds = [
            'max_orders'   => max(max($orderCounts), 1),
            'max_spend'    => max(max($spends), 1),
            'recency_warm' => 60,   // ≤60 days = warm customer
            'recency_cold' => 180,  // >180 days = cold/lapsed
        ];

        return $this->thresholds;
    }

    // ─────────────────────────────────────────────────────────
    //  predict($task)
    //  Dispatcher — supported tasks:
    //    'reorder'   : main Order Prediction model
    //    'sentiment' : VADER sentiment on order notes
    //    'summary'   : aggregated numbers for the hero section
    // ─────────────────────────────────────────────────────────
    public function predict(string $task): array
    {
        if (empty($this->processedData)) $this->preprocessData();
        if (empty($this->thresholds))    $this->trainModel();

        switch ($task) {
            case 'reorder':   return $this->predictReorder();
            case 'sentiment': return $this->analyzeSentiment();
            case 'summary':   return $this->buildSummary();
            default:          return [];
        }
    }

    // ─────────────────────────────────────────────────────────
    //  MAIN MODEL — predictReorder()
    //
    //  For every customer, computes a 0-100 likelihood score
    //  from 5 weighted features and maps to a label + advice.
    //  Returns full per-feature breakdown so the UI can show
    //  exactly why the model produced each prediction.
    // ─────────────────────────────────────────────────────────
    private function predictReorder(): array
    {
        $results = [];
        $t = $this->thresholds;
        $w = self::WEIGHTS;

        foreach ($this->processedData['customers'] as $c) {
            $count     = (int)   $c['order_count'];
            $completed = (int)   $c['completed_orders'];
            $cancelled = (int)   $c['cancelled_orders'];
            $spent     = (float) $c['total_spent'];

            if ($count === 0) {
                $results[] = $this->zeroOrderRow($c);
                continue;
            }

            $daysSince = $c['last_order_date']
                ? (int) ((time() - strtotime($c['last_order_date'])) / 86400)
                : 999;

            // ── Feature 1: Frequency ──────────────────────────
            $freqScore = min(($count / $t['max_orders']) * 100, 100);

            // ── Feature 2: Loyalty (completion rate) ──────────
            $loyaltyScore = ($completed / $count) * 100;

            // ── Feature 3: Recency ────────────────────────────
            if ($daysSince <= 30) {
                $recencyScore = 100;
            } elseif ($daysSince <= $t['recency_warm']) {
                $recencyScore = 100 - (($daysSince - 30) / ($t['recency_warm'] - 30)) * 35;
            } elseif ($daysSince <= $t['recency_cold']) {
                $recencyScore = 65 - (($daysSince - $t['recency_warm']) / ($t['recency_cold'] - $t['recency_warm'])) * 55;
            } else {
                $recencyScore = max(0, 10 - ($daysSince - $t['recency_cold']) / 30);
            }

            // ── Feature 4: Spend ──────────────────────────────
            $spendScore = min(($spent / $t['max_spend']) * 100, 100);

            // ── Feature 5: Cancellation penalty ──────────────
            $cancelPenalty = ($cancelled / $count) * 100;

            // ── Weighted score ────────────────────────────────
            $raw = ($freqScore    * $w['frequency'])
                 + ($loyaltyScore * $w['loyalty'])
                 + ($recencyScore * $w['recency'])
                 + ($spendScore   * $w['spend'])
                 - ($cancelPenalty * $w['cancel_pen']);

            $score = (int) max(3, min(97, round($raw)));

            [$label, $color, $icon, $advice] = $this->scoreToLabel(
                $score, $daysSince, $cancelled, $count
            );

            $results[] = [
                'id'              => $c['id'],
                'name'            => $c['name'],
                'email'           => $c['email'],
                'score'           => $score,
                'label'           => $label,
                'color'           => $color,
                'icon'            => $icon,
                'advice'          => $advice,
                'days_since'      => $daysSince >= 999 ? null : $daysSince,
                'order_count'     => $count,
                'completed'       => $completed,
                'cancelled'       => $cancelled,
                'total_spent'     => $spent,
                'features' => [
                    'frequency'  => (int) round($freqScore),
                    'loyalty'    => (int) round($loyaltyScore),
                    'recency'    => (int) round(max(0, $recencyScore)),
                    'spend'      => (int) round($spendScore),
                    'cancel_pen' => (int) round($cancelPenalty),
                ],
            ];
        }

        usort($results, fn($a, $b) => $b['score'] <=> $a['score']);
        return $results;
    }

    private function scoreToLabel(int $score, int $days, int $cancelled, int $total): array
    {
        $cancelRate = $total > 0 ? $cancelled / $total : 0;

        if ($score >= 75) {
            return ['Very Likely', 'green', 'bi-arrow-repeat',
                'Strong order history and recent activity. High reorder probability.'];
        }
        if ($score >= 55) {
            return ['Likely', 'blue', 'bi-clock-history',
                'Moderate engagement. A follow-up or promotion may convert them.'];
        }
        if ($score >= 35) {
            if ($cancelRate > 0.3) {
                return ['Uncertain', 'amber', 'bi-exclamation-circle',
                    'High cancellation rate reduces confidence. Address any service issues.'];
            }
            return ['Uncertain', 'amber', 'bi-exclamation-circle',
                'Activity is declining. Re-engagement recommended before they go cold.'];
        }
        return ['Unlikely', 'red', 'bi-x-circle',
            'Low engagement or long inactivity. Consider a win-back campaign.'];
    }

    private function zeroOrderRow(array $c): array
    {
        return [
            'id' => $c['id'], 'name' => $c['name'], 'email' => $c['email'],
            'score' => 0, 'label' => 'No Orders', 'color' => 'muted',
            'icon' => 'bi-dash-circle', 'advice' => 'No order history — cannot predict yet.',
            'days_since' => null, 'order_count' => 0, 'completed' => 0,
            'cancelled' => 0, 'total_spent' => 0,
            'features' => ['frequency'=>0,'loyalty'=>0,'recency'=>0,'spend'=>0,'cancel_pen'=>0],
        ];
    }

    // ─────────────────────────────────────────────────────────
    //  analyzeSentiment()
    //  Uses davmixcool/php-sentiment-analyzer (VADER) to score
    //  the sentiment of each order note.
    // ─────────────────────────────────────────────────────────
    public function analyzeSentiment(): array
    {
        $rows   = [];
        $totals = ['pos' => 0.0, 'neg' => 0.0, 'neu' => 0.0];
        $count  = 0;

        foreach ($this->processedData['notes'] as $row) {
            if (empty(trim($row['notes']))) continue;

            $scores = $this->analyzer->getSentiment($row['notes']);
            arsort($scores);
            $dominant = array_key_first($scores);

            [$label, $color, $icon] = match($dominant) {
                'pos'   => ['Positive', 'green', 'bi-emoji-smile-fill'],
                'neg'   => ['Negative', 'red',   'bi-emoji-frown-fill'],
                default => ['Neutral',  'amber',  'bi-emoji-neutral-fill'],
            };

            $rows[] = [
                'order_id'      => $row['id'],
                'product'       => $row['product'],
                'customer_name' => $row['customer_name'],
                'note'          => $row['notes'],
                'pos'           => round($scores['pos'] * 100, 1),
                'neg'           => round($scores['neg'] * 100, 1),
                'neu'           => round($scores['neu'] * 100, 1),
                'label'         => $label,
                'color'         => $color,
                'icon'          => $icon,
            ];

            $totals['pos'] += $scores['pos'];
            $totals['neg'] += $scores['neg'];
            $totals['neu'] += $scores['neu'];
            $count++;
        }

        $avgPos = $count ? round(($totals['pos'] / $count) * 100, 1) : 0;
        $avgNeg = $count ? round(($totals['neg'] / $count) * 100, 1) : 0;
        $avgNeu = $count ? round(($totals['neu'] / $count) * 100, 1) : 0;

        $tmp = ['pos' => $avgPos, 'neg' => $avgNeg, 'neu' => $avgNeu];
        arsort($tmp);
        [$overall, $overallColor] = match(array_key_first($tmp)) {
            'pos'   => ['Positive', 'green'],
            'neg'   => ['Negative', 'red'],
            default => ['Neutral',  'amber'],
        };

        return compact('rows', 'count', 'overall', 'overallColor', 'avgPos', 'avgNeg', 'avgNeu');
    }

    // ─────────────────────────────────────────────────────────
    //  buildSummary() — aggregates prediction counts for the
    //  hero section of the dashboard.
    // ─────────────────────────────────────────────────────────
    private function buildSummary(): array
    {
        $predictions = $this->predictReorder();

        $counts = ['Very Likely'=>0,'Likely'=>0,'Uncertain'=>0,'Unlikely'=>0,'No Orders'=>0];
        $scoreSum = 0; $scoreN = 0;

        foreach ($predictions as $p) {
            $counts[$p['label']] = ($counts[$p['label']] ?? 0) + 1;
            if ($p['score'] > 0) { $scoreSum += $p['score']; $scoreN++; }
        }

        return [
            'predictions' => $predictions,
            'counts'      => $counts,
            'total'       => count($predictions),
            'avg_score'   => $scoreN ? (int) round($scoreSum / $scoreN) : 0,
        ];
    }
}
