<?php
// classes/Customer.php
class Customer {
    private $conn;
    private $table = 'customers';

    public $id;
    public $name;
    public $email;
    public $phone;
    public $address;
    public $created_by;

    public function __construct($db) {
        $this->conn = $db;
    }

    // Get all customers with creator info
    public function getAll() {
        $query = "SELECT c.*, u.full_name AS created_by_name
                  FROM {$this->table} c
                  LEFT JOIN users u ON c.created_by = u.id
                  ORDER BY c.created_at DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    // Get single customer
    public function getById($id) {
        $query = "SELECT c.*, u.full_name AS created_by_name
                  FROM {$this->table} c
                  LEFT JOIN users u ON c.created_by = u.id
                  WHERE c.id = :id LIMIT 1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch();
    }

    // Create customer
    public function create() {
        $query = "INSERT INTO {$this->table} (name, email, phone, address, created_by)
                  VALUES (:name, :email, :phone, :address, :created_by)";
        $stmt = $this->conn->prepare($query);

        $this->name       = htmlspecialchars(strip_tags($this->name));
        $this->email      = htmlspecialchars(strip_tags($this->email));
        $this->phone      = htmlspecialchars(strip_tags($this->phone));
        $this->address    = htmlspecialchars(strip_tags($this->address));
        $this->created_by = (int)$this->created_by;

        $stmt->bindParam(':name',       $this->name);
        $stmt->bindParam(':email',      $this->email);
        $stmt->bindParam(':phone',      $this->phone);
        $stmt->bindParam(':address',    $this->address);
        $stmt->bindParam(':created_by', $this->created_by);

        return $stmt->execute();
    }

    // Update customer
    public function update() {
        $query = "UPDATE {$this->table} SET name=:name, email=:email, phone=:phone, address=:address WHERE id=:id";
        $stmt = $this->conn->prepare($query);

        $this->name    = htmlspecialchars(strip_tags($this->name));
        $this->email   = htmlspecialchars(strip_tags($this->email));
        $this->phone   = htmlspecialchars(strip_tags($this->phone));
        $this->address = htmlspecialchars(strip_tags($this->address));

        $stmt->bindParam(':name',    $this->name);
        $stmt->bindParam(':email',   $this->email);
        $stmt->bindParam(':phone',   $this->phone);
        $stmt->bindParam(':address', $this->address);
        $stmt->bindParam(':id',      $this->id);

        return $stmt->execute();
    }

    // Delete customer
    public function delete($id) {
        $query = "DELETE FROM {$this->table} WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        return $stmt->execute();
    }

    // Count customers
    public function count() {
        $stmt = $this->conn->query("SELECT COUNT(*) as total FROM {$this->table}");
        $row = $stmt->fetch();
        return $row['total'];
    }

    // Get all customers for dropdown
    public function getAllSimple() {
        $query = "SELECT id, name FROM {$this->table} ORDER BY name ASC";
        $stmt  = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll();
    }
}
