<?php
// classes/User.php
require_once __DIR__ . '/../config/Database.php';

class User {
    private $conn;
    private $table = 'users';

    public $id;
    public $username;
    public $full_name;
    public $email;
    public $password;
    public $role;

    public function __construct($db) {
        $this->conn = $db;
    }

    // Get all users
    public function getAll() {
        $query = "SELECT id, username, full_name, email, role, created_at FROM {$this->table} ORDER BY created_at DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    // Get single user by ID
    public function getById($id) {
        $query = "SELECT id, username, full_name, email, role, created_at FROM {$this->table} WHERE id = :id LIMIT 1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch();
    }

    // Get user by username
    public function getByUsername($username) {
        $query = "SELECT * FROM {$this->table} WHERE username = :username LIMIT 1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':username', $username);
        $stmt->execute();
        return $stmt->fetch();
    }

    // Create new user
    public function create() {
        $query = "INSERT INTO {$this->table} (username, full_name, email, password, role)
                  VALUES (:username, :full_name, :email, :password, :role)";
        $stmt = $this->conn->prepare($query);

        $this->username   = htmlspecialchars(strip_tags($this->username));
        $this->full_name  = htmlspecialchars(strip_tags($this->full_name));
        $this->email      = htmlspecialchars(strip_tags($this->email));
        $this->role       = htmlspecialchars(strip_tags($this->role));
        $hashedPassword   = password_hash($this->password, PASSWORD_BCRYPT);

        $stmt->bindParam(':username',  $this->username);
        $stmt->bindParam(':full_name', $this->full_name);
        $stmt->bindParam(':email',     $this->email);
        $stmt->bindParam(':password',  $hashedPassword);
        $stmt->bindParam(':role',      $this->role);

        return $stmt->execute();
    }

    // Update user
    public function update() {
        if (!empty($this->password)) {
            $query = "UPDATE {$this->table} SET username=:username, full_name=:full_name, email=:email, password=:password, role=:role WHERE id=:id";
        } else {
            $query = "UPDATE {$this->table} SET username=:username, full_name=:full_name, email=:email, role=:role WHERE id=:id";
        }
        $stmt = $this->conn->prepare($query);

        $this->username  = htmlspecialchars(strip_tags($this->username));
        $this->full_name = htmlspecialchars(strip_tags($this->full_name));
        $this->email     = htmlspecialchars(strip_tags($this->email));
        $this->role      = htmlspecialchars(strip_tags($this->role));

        $stmt->bindParam(':username',  $this->username);
        $stmt->bindParam(':full_name', $this->full_name);
        $stmt->bindParam(':email',     $this->email);
        $stmt->bindParam(':role',      $this->role);
        $stmt->bindParam(':id',        $this->id);

        if (!empty($this->password)) {
            $hashedPassword = password_hash($this->password, PASSWORD_BCRYPT);
            $stmt->bindParam(':password', $hashedPassword);
        }
        return $stmt->execute();
    }

    // Delete user
    public function delete($id) {
        $query = "DELETE FROM {$this->table} WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        return $stmt->execute();
    }

    // Count users
    public function count() {
        $stmt = $this->conn->query("SELECT COUNT(*) as total FROM {$this->table}");
        $row = $stmt->fetch();
        return $row['total'];
    }

    // Check if username already exists (for validation)
    public function usernameExists($username, $excludeId = null) {
        if ($excludeId) {
            $query = "SELECT id FROM {$this->table} WHERE username = :username AND id != :id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':id', $excludeId);
        } else {
            $query = "SELECT id FROM {$this->table} WHERE username = :username";
            $stmt = $this->conn->prepare($query);
        }
        $stmt->bindParam(':username', $username);
        $stmt->execute();
        return $stmt->rowCount() > 0;
    }
}
