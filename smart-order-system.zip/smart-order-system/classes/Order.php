<?php
// classes/Order.php
class Order {
    private $conn;
    private $table = 'orders';

    public $id;
    public $customer_id;
    public $user_id;
    public $product;
    public $quantity;
    public $price;
    public $status;
    public $notes;

    public function __construct($db) {
        $this->conn = $db;
    }

    // Get all orders with JOIN (customer name + staff name)
    public function getAll() {
        $query = "SELECT o.*,
                         c.name   AS customer_name,
                         c.email  AS customer_email,
                         u.full_name AS created_by,
                         u.username  AS staff_username,
                         (o.quantity * o.price) AS total_amount
                  FROM {$this->table} o
                  JOIN customers c ON o.customer_id = c.id
                  JOIN users     u ON o.user_id     = u.id
                  ORDER BY o.created_at DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    // Get single order
    public function getById($id) {
        $query = "SELECT o.*,
                         c.name      AS customer_name,
                         u.full_name AS created_by
                  FROM {$this->table} o
                  JOIN customers c ON o.customer_id = c.id
                  JOIN users     u ON o.user_id     = u.id
                  WHERE o.id = :id LIMIT 1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch();
    }

    // Create order
    public function create() {
        $query = "INSERT INTO {$this->table} (customer_id, user_id, product, quantity, price, status, notes)
                  VALUES (:customer_id, :user_id, :product, :quantity, :price, :status, :notes)";
        $stmt = $this->conn->prepare($query);

        $this->product     = htmlspecialchars(strip_tags($this->product));
        $this->notes       = htmlspecialchars(strip_tags($this->notes));
        $this->status      = htmlspecialchars(strip_tags($this->status));
        $this->customer_id = (int)$this->customer_id;
        $this->user_id     = (int)$this->user_id;
        $this->quantity    = (int)$this->quantity;
        $this->price       = (float)$this->price;

        $stmt->bindParam(':customer_id', $this->customer_id);
        $stmt->bindParam(':user_id',     $this->user_id);
        $stmt->bindParam(':product',     $this->product);
        $stmt->bindParam(':quantity',    $this->quantity);
        $stmt->bindParam(':price',       $this->price);
        $stmt->bindParam(':status',      $this->status);
        $stmt->bindParam(':notes',       $this->notes);

        return $stmt->execute();
    }

    // Update order
    public function update() {
        $query = "UPDATE {$this->table}
                  SET customer_id=:customer_id, product=:product, quantity=:quantity,
                      price=:price, status=:status, notes=:notes
                  WHERE id=:id";
        $stmt = $this->conn->prepare($query);

        $this->product     = htmlspecialchars(strip_tags($this->product));
        $this->notes       = htmlspecialchars(strip_tags($this->notes));
        $this->status      = htmlspecialchars(strip_tags($this->status));
        $this->customer_id = (int)$this->customer_id;
        $this->quantity    = (int)$this->quantity;
        $this->price       = (float)$this->price;

        $stmt->bindParam(':customer_id', $this->customer_id);
        $stmt->bindParam(':product',     $this->product);
        $stmt->bindParam(':quantity',    $this->quantity);
        $stmt->bindParam(':price',       $this->price);
        $stmt->bindParam(':status',      $this->status);
        $stmt->bindParam(':notes',       $this->notes);
        $stmt->bindParam(':id',          $this->id);

        return $stmt->execute();
    }

    // Delete order
    public function delete($id) {
        $query = "DELETE FROM {$this->table} WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        return $stmt->execute();
    }

    // Count orders
    public function count() {
        $stmt = $this->conn->query("SELECT COUNT(*) as total FROM {$this->table}");
        $row = $stmt->fetch();
        return $row['total'];
    }

    // Count by status
    public function countByStatus($status) {
        $query = "SELECT COUNT(*) as total FROM {$this->table} WHERE status = :status";
        $stmt  = $this->conn->prepare($query);
        $stmt->bindParam(':status', $status);
        $stmt->execute();
        $row = $stmt->fetch();
        return $row['total'];
    }

    // Total revenue (completed)
    public function totalRevenue() {
        $query = "SELECT SUM(quantity * price) as revenue FROM {$this->table} WHERE status = 'completed'";
        $stmt  = $this->conn->prepare($query);
        $stmt->execute();
        $row = $stmt->fetch();
        return $row['revenue'] ?? 0;
    }

    // Get orders by customer
    public function getByCustomer($customer_id) {
        $query = "SELECT o.*, u.full_name AS created_by
                  FROM {$this->table} o
                  JOIN users u ON o.user_id = u.id
                  WHERE o.customer_id = :customer_id
                  ORDER BY o.created_at DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':customer_id', $customer_id);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    // Recent orders for dashboard
    public function getRecent($limit = 5) {
        $query = "SELECT o.*,
                         c.name      AS customer_name,
                         u.full_name AS created_by,
                         (o.quantity * o.price) AS total_amount
                  FROM {$this->table} o
                  JOIN customers c ON o.customer_id = c.id
                  JOIN users     u ON o.user_id     = u.id
                  ORDER BY o.created_at DESC
                  LIMIT :limit";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }
}
