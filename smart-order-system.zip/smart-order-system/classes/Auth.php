<?php
// classes/Auth.php
require_once __DIR__ . '/../config/Database.php';
require_once __DIR__ . '/User.php';

class Auth {
    private $conn;
    private $userObj;

    public function __construct($db) {
        $this->conn    = $db;
        $this->userObj = new User($db);
    }

    // Log in a user
    public function login($username, $password) {
        $username = htmlspecialchars(strip_tags(trim($username)));
        $user = $this->userObj->getByUsername($username);

        if ($user && password_verify($password, $user['password'])) {
            session_regenerate_id(true);
            $_SESSION['user_id']    = $user['id'];
            $_SESSION['username']   = $user['username'];
            $_SESSION['full_name']  = $user['full_name'];
            $_SESSION['role']       = $user['role'];
            $_SESSION['logged_in']  = true;
            return true;
        }
        return false;
    }

    // Log out
    public function logout() {
        session_unset();
        session_destroy();
        header('Location: login.php');
        exit();
    }

    // Check if user is logged in
    public static function check() {
        if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
            header('Location: login.php');
            exit();
        }
    }

    // Get currently logged-in user info from session
    public static function user() {
        return [
            'id'        => $_SESSION['user_id']   ?? null,
            'username'  => $_SESSION['username']  ?? '',
            'full_name' => $_SESSION['full_name'] ?? '',
            'role'      => $_SESSION['role']      ?? '',
        ];
    }

    // Check if admin
    public static function isAdmin() {
        return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
    }
}
