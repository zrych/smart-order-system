<?php
// orders_edit.php
require_once 'includes/session_check.php';
require_once 'config/Database.php';
require_once 'classes/Order.php';
require_once 'classes/Customer.php';

$db       = (new Database())->getConnection();
$order    = new Order($db);
$customer = new Customer($db);
$customers = $customer->getAllSimple();

$id = (int)($_GET['id'] ?? 0);
if (!$id) { header('Location: orders.php'); exit(); }

$record = $order->getById($id);
if (!$record) { header('Location: orders.php'); exit(); }

$errors   = [];
$formData = $record;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $formData['customer_id'] = (int)($_POST['customer_id'] ?? 0);
    $formData['product']     = trim($_POST['product']      ?? '');
    $formData['quantity']    = (int)($_POST['quantity']    ?? 1);
    $formData['price']       = trim($_POST['price']        ?? '');
    $formData['status']      = trim($_POST['status']       ?? 'pending');
    $formData['notes']       = trim($_POST['notes']        ?? '');

    if (!$formData['customer_id'])   $errors[] = 'Please select a customer.';
    if (empty($formData['product'])) $errors[] = 'Product name is required.';
    if ($formData['quantity'] < 1)   $errors[] = 'Quantity must be at least 1.';
    if (!is_numeric($formData['price']) || $formData['price'] < 0)
                                     $errors[] = 'Please enter a valid price.';

    if (empty($errors)) {
        $order->id          = $id;
        $order->customer_id = $formData['customer_id'];
        $order->product     = $formData['product'];
        $order->quantity    = $formData['quantity'];
        $order->price       = $formData['price'];
        $order->status      = $formData['status'];
        $order->notes       = $formData['notes'];

        if ($order->update()) {
            header('Location: orders.php?success=updated');
            exit();
        } else {
            $errors[] = 'Failed to update order.';
        }
    }
}

$pageTitle  = 'Edit Order';
$activePage = 'orders';
include 'includes/header.php';
?>

<div class="page-header">
    <div>
        <h1><i class="bi bi-pencil-square me-2" style="color:var(--red);"></i>Edit Order</h1>
        <p>Order #<?= str_pad($id, 4, '0', STR_PAD_LEFT) ?> — <?= htmlspecialchars($record['product']) ?></p>
    </div>
    <a href="orders.php" class="btn-secondary-custom">
        <i class="bi bi-arrow-left"></i> Back to Orders
    </a>
</div>

<?php if (!empty($errors)): ?>
    <div class="alert alert-danger mb-3">
        <?php foreach ($errors as $e): ?>
            <div><i class="bi bi-exclamation-circle-fill me-1"></i><?= htmlspecialchars($e) ?></div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<div class="form-card">
    <form method="POST" novalidate>
        <div class="mb-3">
            <label class="form-label">Customer <span style="color:var(--red)">*</span></label>
            <select name="customer_id" class="form-select" required>
                <option value="">— Select Customer —</option>
                <?php foreach ($customers as $c): ?>
                    <option value="<?= $c['id'] ?>"
                        <?= $formData['customer_id'] == $c['id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($c['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Product / Item <span style="color:var(--red)">*</span></label>
            <input type="text" name="product" class="form-control"
                   value="<?= htmlspecialchars($formData['product']) ?>" required>
        </div>

        <div class="row g-3">
            <div class="col-md-4">
                <label class="form-label">Quantity <span style="color:var(--red)">*</span></label>
                <input type="number" name="quantity" class="form-control"
                       min="1" value="<?= $formData['quantity'] ?>" required>
            </div>
            <div class="col-md-4">
                <label class="form-label">Unit Price (₱) <span style="color:var(--red)">*</span></label>
                <input type="number" name="price" class="form-control"
                       min="0" step="0.01" value="<?= $formData['price'] ?>" required>
            </div>
            <div class="col-md-4">
                <label class="form-label">Status</label>
                <select name="status" class="form-select">
                    <option value="pending"    <?= $formData['status']==='pending'    ? 'selected':'' ?>>Pending</option>
                    <option value="processing" <?= $formData['status']==='processing' ? 'selected':'' ?>>Processing</option>
                    <option value="completed"  <?= $formData['status']==='completed'  ? 'selected':'' ?>>Completed</option>
                    <option value="cancelled"  <?= $formData['status']==='cancelled'  ? 'selected':'' ?>>Cancelled</option>
                </select>
            </div>
        </div>

        <div class="mt-3 mb-4">
            <label class="form-label">Notes</label>
            <textarea name="notes" class="form-control" rows="3"><?= htmlspecialchars($formData['notes'] ?? '') ?></textarea>
        </div>

        <div class="d-flex gap-2">
            <button type="submit" class="btn-primary-custom">
                <i class="bi bi-check-lg"></i> Update Order
            </button>
            <a href="orders.php" class="btn-secondary-custom">
                <i class="bi bi-x-lg"></i> Cancel
            </a>
        </div>
    </form>
</div>

<?php include 'includes/footer.php'; ?>
