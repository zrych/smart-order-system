<?php
// users.php
require_once 'includes/session_check.php';
if (!Auth::isAdmin()) {
    header('Location: dashboard.php');
    exit();
}
require_once 'config/Database.php';
require_once 'classes/User.php';

$db    = (new Database())->getConnection();
$user  = new User($db);
$users = $user->getAll();

$success    = $_GET['success'] ?? '';
$pageTitle  = 'Users';
$activePage = 'users';
include 'includes/header.php';
?>

<?php if ($success === 'created'): ?>
    <div class="alert alert-success alert-dismissible alert-auto-dismiss mb-3">
        <i class="bi bi-check-circle-fill me-2"></i> User created successfully!
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php elseif ($success === 'updated'): ?>
    <div class="alert alert-success alert-dismissible alert-auto-dismiss mb-3">
        <i class="bi bi-check-circle-fill me-2"></i> User updated successfully!
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php elseif ($success === 'deleted'): ?>
    <div class="alert alert-danger alert-dismissible alert-auto-dismiss mb-3">
        <i class="bi bi-trash-fill me-2"></i> User deleted.
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<div class="page-header">
    <div>
        <h1><i class="bi bi-shield-person-fill me-2" style="color:var(--red);"></i>System Users</h1>
        <p><?= count($users) ?> user(s) — admin access required</p>
    </div>
    <a href="users_add.php" class="btn-primary-custom">
        <i class="bi bi-person-plus-fill"></i> Add User
    </a>
</div>

<div class="table-wrapper">
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Full Name</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Date Created</th>
                    <th class="text-center">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $u): ?>
                <tr>
                    <td style="font-family:'Space Mono',monospace;font-size:0.78rem;color:var(--gray-400);"><?= str_pad($u['id'], 3, '0', STR_PAD_LEFT) ?></td>
                    <td>
                        <div class="d-flex align-items-center gap-2">
                            <div style="width:32px;height:32px;background:<?= $u['role']==='admin' ? 'var(--red-bg)' : 'var(--blue-bg)' ?>;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:0.9rem;color:<?= $u['role']==='admin' ? 'var(--red-dark)' : 'var(--blue-dark)' ?>;">
                                <i class="bi bi-person-fill"></i>
                            </div>
                            <strong><?= htmlspecialchars($u['full_name']) ?></strong>
                        </div>
                    </td>
                    <td><code>@<?= htmlspecialchars($u['username']) ?></code></td>
                    <td><?= htmlspecialchars($u['email']) ?></td>
                    <td>
                        <span class="badge-role <?= $u['role']==='admin' ? 'badge-admin' : 'badge-staff' ?>">
                            <i class="bi bi-circle-fill"></i> <?= ucfirst($u['role']) ?>
                        </span>
                    </td>
                    <td style="font-size:0.78rem;color:var(--gray-400);"><?= date('M d, Y', strtotime($u['created_at'])) ?></td>
                    <td class="text-center">
                        <div class="d-flex gap-1 justify-content-center">
                            <a href="users_edit.php?id=<?= $u['id'] ?>" class="btn-action btn-edit" title="Edit">
                                <i class="bi bi-pencil-fill"></i>
                            </a>
                            <?php if ($u['id'] != $currentUser['id']): ?>
                            <a href="users_delete.php?id=<?= $u['id'] ?>"
                               class="btn-action btn-delete"
                               title="Delete"
                               onclick="return confirm('Delete user <?= htmlspecialchars($u['username']) ?>?')">
                                <i class="bi bi-trash-fill"></i>
                            </a>
                            <?php else: ?>
                            <span class="btn-action" style="background:var(--gray-200);color:var(--gray-400);cursor:default;" title="Cannot delete yourself">
                                <i class="bi bi-lock-fill"></i>
                            </span>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
