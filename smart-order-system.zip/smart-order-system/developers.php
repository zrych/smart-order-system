<?php
// developers.php
require_once 'includes/session_check.php';
$pageTitle  = 'Developers';
$activePage = 'developers';
include 'includes/header.php';
?>

<div class="page-header">
    <div>
        <h1><i class="bi bi-code-slash me-2" style="color:var(--red);"></i>Meet the Developers</h1>
        <p>ITEL 203 — Web Systems and Technologies · Group Performance Task #2</p>
    </div>
</div>

<!-- Team Banner -->
<div style="background:linear-gradient(135deg, var(--black-soft), var(--black-mid));
            border-radius:var(--radius-lg);padding:32px 28px;margin-bottom:28px;
            position:relative;overflow:hidden;">
    <!-- Decorative blobs -->
    <div style="position:absolute;top:-40%;left:-5%;width:300px;height:300px;
                background:radial-gradient(circle,rgba(116,185,255,0.1),transparent 70%);
                border-radius:50%;pointer-events:none;"></div>
    <div style="position:absolute;bottom:-40%;right:-5%;width:260px;height:260px;
                background:radial-gradient(circle,rgba(255,107,107,0.09),transparent 70%);
                border-radius:50%;pointer-events:none;"></div>
    <!-- Grid dots -->
    <div style="position:absolute;inset:0;
                background-image:radial-gradient(rgba(255,255,255,0.04) 1px,transparent 1px);
                background-size:24px 24px;pointer-events:none;"></div>

    <div style="position:relative;z-index:1;text-align:center;">
        <div style="display:inline-flex;align-items:center;justify-content:center;gap:8px;
                    background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.1);
                    padding:5px 16px;border-radius:50px;margin-bottom:14px;">
            <span style="font-size:0.72rem;font-weight:700;color:var(--blue);text-transform:uppercase;
                          letter-spacing:1px;">ITEL 203</span>
        </div>
        <h2 style="font-size:1.5rem;font-weight:800;color:#fff;letter-spacing:-0.5px;margin-bottom:6px;">
            Group Performance Task #2
        </h2>
        <p style="font-size:0.85rem;color:rgba(255,255,255,0.5);max-width:440px;margin:0 auto;">
            Secure OOP PHP Web Application with Relational Database
        </p>
    </div>
</div>

<!-- Developer Cards -->
<div class="row g-4 mb-4">
    <?php
    $developers = [
        [
            'name'    => 'Raven Robles',
            'role'    => 'Front-End Developer',
            'tasks'   => 'UI/UX design, Bootstrap layout, responsive styling, CSS animations, and page structure',
            'emoji'   => '🎨',
            'color'   => 'var(--blue-dark)',
            'accent'  => 'var(--blue-bg)',
        ],
        [
            'name'    => 'Manuel Tan',
            'role'    => 'Back-End Developer',
            'tasks'   => 'OOP PHP architecture, CRUD operations, database design, JOIN queries, and session management',
            'emoji'   => '⚙️',
            'accent'  => 'var(--red-bg)',
            'color'   => 'var(--red-dark)',
        ],
        [
            'name'    => 'Keiron De Sagun',
            'role'    => 'Back-End & Deployment',
            'tasks'   => 'Server configuration, InfinityFree deployment, GitHub repository management, and live testing',
            'emoji'   => '🚀',
            'accent'  => 'var(--green-bg)',
            'color'   => '#065f46',
        ],
    ];
    foreach ($developers as $dev):
    ?>
    <div class="col-md-4">
        <div class="dev-card">
            <div class="dev-avatar" style="background:<?= $dev['accent'] ?>;">
                <div class="dev-avatar-ring"></div>
                <div class="dev-avatar-inner" style="background:<?= $dev['accent'] ?>;">
                    <?= $dev['emoji'] ?>
                </div>
            </div>
            <div class="dev-name"><?= htmlspecialchars($dev['name']) ?></div>
            <div class="dev-role-text" style="color:<?= $dev['color'] ?>;">
                <i class="bi bi-patch-check-fill me-1" style="font-size:0.72rem;"></i>
                <?= htmlspecialchars($dev['role']) ?>
            </div>
            <div class="dev-tasks">
                <i class="bi bi-list-check me-1" style="color:var(--blue-dark);"></i>
                <?= htmlspecialchars($dev['tasks']) ?>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<!-- Project Details + Lessons -->
<div class="row g-4">
    <div class="col-lg-6">
        <div class="about-section h-100">
            <h6 style="font-weight:800;margin-bottom:16px;font-size:0.88rem;color:var(--text-primary);">
                <i class="bi bi-journals me-2" style="color:var(--red);"></i>Project Details
            </h6>
            <?php
            $details = [
                ['bi-mortarboard-fill',  'Course',   'ITEL 203 — Web Systems and Technologies'],
                ['bi-file-earmark-text', 'Task',     'Group Performance Task #2'],
                ['bi-cpu-fill',          'Topic',    'Secure OOP PHP Web Application'],
                ['bi-database-fill',     'Database', 'MySQL · 3 relational tables · Foreign keys'],
                ['bi-stack',             'Stack',    'PHP · MySQL · Bootstrap 5 · CSS3'],
                ['bi-tools',             'Tools',    'XAMPP · VSCode · GitHub · InfinityFree'],
            ];
            foreach ($details as [$icon, $label, $val]):
            ?>
            <div style="display:flex;align-items:flex-start;gap:12px;padding:9px 0;
                         border-bottom:1px solid var(--border-soft);">
                <div style="width:28px;height:28px;background:var(--red-bg);border-radius:6px;
                             display:flex;align-items:center;justify-content:center;flex-shrink:0;margin-top:1px;">
                    <i class="bi <?= $icon ?>" style="font-size:0.75rem;color:var(--red-dark);"></i>
                </div>
                <div>
                    <div style="font-size:0.7rem;font-weight:700;text-transform:uppercase;letter-spacing:0.4px;
                                 color:var(--text-muted);margin-bottom:1px;"><?= $label ?></div>
                    <div style="font-size:0.85rem;color:var(--text-primary);"><?= $val ?></div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <div class="col-lg-6">
        <div class="about-section h-100">
            <h6 style="font-weight:800;margin-bottom:16px;font-size:0.88rem;color:var(--text-primary);">
                <i class="bi bi-lightbulb-fill me-2" style="color:var(--blue-dark);"></i>Lessons Learned
            </h6>
            <?php
            $lessons = [
                ['bi-braces',          'Applying OOP in PHP — classes, encapsulation, and methods'],
                ['bi-diagram-3',       'Designing relational databases with foreign key constraints'],
                ['bi-table',           'Writing JOIN queries to display linked table data'],
                ['bi-shield-lock',     'Secure session-based auth with hashed passwords'],
                ['bi-arrow-repeat',    'Full CRUD operations across multiple related tables'],
                ['bi-globe',           'Deploying a live PHP app on InfinityFree hosting'],
                ['bi-git',             'Collaborating as a team using GitHub version control'],
            ];
            foreach ($lessons as $i => [$icon, $lesson]):
            ?>
            <div style="display:flex;align-items:center;gap:12px;padding:8px 0;
                         border-bottom:1px solid var(--border-soft);">
                <div style="width:26px;height:26px;background:var(--blue-bg);border-radius:6px;
                             display:flex;align-items:center;justify-content:center;flex-shrink:0;">
                    <i class="bi <?= $icon ?>" style="font-size:0.72rem;color:var(--blue-dark);"></i>
                </div>
                <div style="font-size:0.84rem;color:var(--text-secondary);"><?= $lesson ?></div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
