<?php
// developers.php
require_once 'includes/session_check.php';
$pageTitle  = 'Developers';
$activePage = 'developers';
include 'includes/header.php';
?>

<div class="page-header">
    <div>
        <h1><i class="bi bi-code-slash me-2" style="color:var(--red);"></i>Meet the Developers</h1>
        <p>ITEL 203 Group Performance Task #2 — Smart Order Management System</p>
    </div>
</div>

<!-- Team Banner -->
<div style="background:linear-gradient(135deg,var(--black-soft),var(--black-mid));border-radius:var(--radius);padding:32px;margin-bottom:28px;text-align:center;position:relative;overflow:hidden;">
    <div style="position:absolute;top:-40%;left:-10%;width:50%;height:200%;background:radial-gradient(ellipse,rgba(116,185,255,0.08) 0%,transparent 70%);"></div>
    <div style="position:absolute;bottom:-40%;right:-10%;width:50%;height:200%;background:radial-gradient(ellipse,rgba(255,107,107,0.08) 0%,transparent 70%);"></div>
    <div style="position:relative;z-index:1;">
        <div style="font-size:2rem;margin-bottom:8px;">👨‍💻👩‍💻👨‍💻</div>
        <div style="font-family:'Space Mono',monospace;font-size:1.2rem;font-weight:700;color:#fff;margin-bottom:6px;">Development Team</div>
        <div style="font-size:0.85rem;color:rgba(255,255,255,0.5);">ITEL 203 — Web Systems and Technologies</div>
    </div>
</div>

<!-- Developer Cards -->
<div class="row g-4 mb-4">
    <?php
    $developers = [
        [
            'name'   => 'Developer 1',
            'role'   => 'Lead Developer',
            'tasks'  => 'Database design, OOP architecture, Authentication system',
            'icon'   => '🧑‍💻',
            'color'  => 'var(--red)',
        ],
        [
            'name'   => 'Developer 2',
            'role'   => 'Backend Developer',
            'tasks'  => 'CRUD operations, Order management, JOIN queries',
            'icon'   => '👩‍💻',
            'color'  => 'var(--blue-dark)',
        ],
        [
            'name'   => 'Developer 3',
            'role'   => 'Frontend & Deployment',
            'tasks'  => 'UI/UX design, Bootstrap layout, InfinityFree deployment',
            'icon'   => '🧑‍🎨',
            'color'  => '#2d8a4e',
        ],
    ];
    foreach ($developers as $dev):
    ?>
    <div class="col-md-4">
        <div class="dev-card">
            <div class="dev-avatar" style="background:linear-gradient(135deg,<?= $dev['color'] ?>,<?= $dev['color'] ?>88);">
                <span style="font-size:1.8rem;"><?= $dev['icon'] ?></span>
            </div>
            <div class="dev-name"><?= htmlspecialchars($dev['name']) ?></div>
            <div class="dev-role" style="color:<?= $dev['color'] ?>;font-weight:600;margin-top:4px;">
                <?= htmlspecialchars($dev['role']) ?>
            </div>
            <div style="margin-top:12px;padding:10px;background:var(--gray-100);border-radius:8px;font-size:0.78rem;color:var(--gray-600);line-height:1.6;">
                <?= htmlspecialchars($dev['tasks']) ?>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<!-- Project Info -->
<div class="row g-4">
    <div class="col-md-6">
        <div class="about-section">
            <h6 style="font-weight:700;margin-bottom:14px;font-family:'Space Mono',monospace;">
                <i class="bi bi-journals me-2" style="color:var(--red);"></i>Project Details
            </h6>
            <?php
            $details = [
                ['Course',    'ITEL 203 — Web Systems and Technologies'],
                ['Task',      'Group Performance Task #2'],
                ['Topic',     'Secure OOP PHP Web Application'],
                ['Database',  'MySQL with Relational Design (3 Tables)'],
                ['Stack',     'PHP · MySQL · Bootstrap · CSS'],
                ['Tools',     'XAMPP · VSCode · GitHub · InfinityFree'],
            ];
            foreach ($details as [$label, $val]): ?>
            <div style="display:flex;gap:10px;padding:8px 0;border-bottom:1px solid var(--gray-200);font-size:0.85rem;">
                <div style="width:90px;font-weight:600;color:var(--gray-600);flex-shrink:0;"><?= $label ?></div>
                <div><?= $val ?></div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    <div class="col-md-6">
        <div class="about-section">
            <h6 style="font-weight:700;margin-bottom:14px;font-family:'Space Mono',monospace;">
                <i class="bi bi-lightbulb-fill me-2" style="color:var(--blue-dark);"></i>Lessons Learned
            </h6>
            <?php
            $lessons = [
                'Applying OOP principles (classes, encapsulation, methods) in PHP',
                'Designing relational databases with foreign keys',
                'Writing JOIN queries to display connected table data',
                'Implementing secure login with session management and password hashing',
                'Building full CRUD operations across multiple related tables',
                'Deploying a live PHP application on InfinityFree hosting',
                'Collaborating as a team using GitHub for version control',
            ];
            foreach ($lessons as $i => $lesson): ?>
            <div style="display:flex;gap:10px;padding:6px 0;border-bottom:1px solid var(--gray-200);font-size:0.83rem;">
                <div style="width:22px;height:22px;background:var(--red-bg);color:var(--red-dark);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:0.7rem;font-weight:700;flex-shrink:0;"><?= $i+1 ?></div>
                <div><?= $lesson ?></div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
