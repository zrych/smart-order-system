<?php
// orders_delete.php
require_once 'includes/session_check.php';
require_once 'config/Database.php';
require_once 'classes/Order.php';

$db    = (new Database())->getConnection();
$order = new Order($db);

$id = (int)($_GET['id'] ?? 0);
if ($id) {
    $order->delete($id);
}
header('Location: orders.php?success=deleted');
exit();
