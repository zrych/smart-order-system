<?php
// about.php
require_once 'includes/session_check.php';
$pageTitle  = 'About';
$activePage = 'about';
include 'includes/header.php';
?>

<div class="page-header">
    <div>
        <h1><i class="bi bi-info-circle-fill me-2" style="color:var(--red);"></i>About This Project</h1>
        <p>ITEL 203 — Web Systems and Technologies · Group Performance Task #2</p>
    </div>
</div>

<div class="row g-4">
    <div class="col-lg-8">
        <div class="about-section mb-4">
            <h5 style="font-family:'Space Mono',monospace;font-weight:700;margin-bottom:12px;">
                <i class="bi bi-box-seam-fill me-2" style="color:var(--red);"></i>
                Smart Order Management System
            </h5>
            <p style="color:var(--gray-600);line-height:1.7;font-size:0.9rem;">
                A web-based system designed to help small businesses track customers, manage orders, and
                monitor which staff member processed each transaction. Built to eliminate the problems of
                manual recording — lost records, order confusion, and lack of accountability.
            </p>
        </div>

        <div class="about-section mb-4">
            <h5 style="font-family:'Space Mono',monospace;font-weight:700;margin-bottom:16px;">
                <i class="bi bi-stack me-2" style="color:var(--blue-dark);"></i>
                Technology Stack
            </h5>
            <div class="row g-3">
                <?php
                $stack = [
                    ['bi-filetype-php',    'PHP 8',        'Object-Oriented Programming with classes, encapsulation, and methods', 'red'],
                    ['bi-database-fill',   'MySQL',        'Relational database with foreign keys, JOIN queries, and 3 core tables', 'blue'],
                    ['bi-bootstrap-fill',  'Bootstrap 5',  'Responsive UI components, grid system, and utility classes', 'black'],
                    ['bi-shield-lock-fill','Sessions',      'Secure authentication with password_hash / password_verify', 'red'],
                    ['bi-git',             'GitHub',        'Version control and team collaboration', 'blue'],
                    ['bi-globe',           'InfinityFree',  'Free hosting for live deployment of the system', 'black'],
                ];
                foreach ($stack as [$icon, $name, $desc, $color]):
                ?>
                <div class="col-md-6">
                    <div style="background:var(--gray-100);border-radius:8px;padding:14px;display:flex;gap:12px;align-items:flex-start;">
                        <div style="width:36px;height:36px;background:<?= $color==='red' ? 'var(--red-bg)' : ($color==='blue' ? 'var(--blue-bg)' : 'rgba(13,13,13,0.06)') ?>;border-radius:8px;display:flex;align-items:center;justify-content:center;flex-shrink:0;">
                            <i class="bi <?= $icon ?>" style="color:<?= $color==='red' ? 'var(--red-dark)' : ($color==='blue' ? 'var(--blue-dark)' : 'var(--black-soft)') ?>;font-size:1rem;"></i>
                        </div>
                        <div>
                            <div style="font-weight:700;font-size:0.88rem;"><?= $name ?></div>
                            <div style="font-size:0.78rem;color:var(--gray-600);margin-top:2px;"><?= $desc ?></div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="about-section">
            <h5 style="font-family:'Space Mono',monospace;font-weight:700;margin-bottom:16px;">
                <i class="bi bi-diagram-3-fill me-2" style="color:var(--red);"></i>
                Database Relationships
            </h5>
            <div style="background:var(--black-soft);border-radius:8px;padding:20px;font-family:'Space Mono',monospace;font-size:0.82rem;color:#fff;line-height:2;">
                <span style="color:var(--blue);">users</span>
                <span style="color:var(--gray-400);"> (id, username, full_name, email, password, role)</span><br>
                &nbsp;&nbsp;<span style="color:var(--gray-400);">↳ One-to-Many →</span>
                <span style="color:var(--red);">customers</span>
                <span style="color:var(--gray-400);"> (id, name, email, phone, address, <u>created_by→users.id</u>)</span><br>
                &nbsp;&nbsp;<span style="color:var(--gray-400);">↳ One-to-Many →</span>
                <span style="color:#ffd93d;">orders</span>
                <span style="color:var(--gray-400);"> (id, <u>customer_id→customers.id</u>, <u>user_id→users.id</u>, product, qty, price, status)</span>
            </div>
        </div>
    </div>

    <div class="col-lg-4">
        <div class="about-section mb-4">
            <h6 style="font-weight:700;margin-bottom:14px;">
                <i class="bi bi-check2-circle me-2" style="color:var(--red);"></i>Features
            </h6>
            <?php
            $features = [
                'Secure login with hashed passwords',
                'Session-based authentication',
                'Full CRUD on customers & orders',
                'JOIN queries across 3 tables',
                'Role-based access (Admin/Staff)',
                'Transaction tracking by staff',
                'Revenue & order status reports',
                'Clean Bootstrap 5 UI',
                'Input validation on all forms',
                'Responsive sidebar navigation',
            ];
            foreach ($features as $f): ?>
            <div style="display:flex;align-items:center;gap:8px;padding:5px 0;font-size:0.85rem;border-bottom:1px solid var(--gray-200);">
                <i class="bi bi-check-circle-fill" style="color:var(--red);font-size:0.75rem;flex-shrink:0;"></i>
                <?= $f ?>
            </div>
            <?php endforeach; ?>
        </div>

        <div class="about-section">
            <h6 style="font-weight:700;margin-bottom:14px;">
                <i class="bi bi-folder2-open me-2" style="color:var(--blue-dark);"></i>OOP File Structure
            </h6>
            <?php
            $files = [
                ['config/Database.php',       'PDO database connection'],
                ['classes/Auth.php',          'Login / logout logic'],
                ['classes/User.php',          'User CRUD model'],
                ['classes/Customer.php',      'Customer CRUD model'],
                ['classes/Order.php',         'Order CRUD + JOIN queries'],
                ['includes/session_check.php','Auth guard for all pages'],
                ['includes/header.php',       'Sidebar + topbar layout'],
                ['assets/style.css',          'External stylesheet'],
            ];
            foreach ($files as [$file, $desc]): ?>
            <div style="padding:5px 0;border-bottom:1px solid var(--gray-200);">
                <div style="font-family:'Space Mono',monospace;font-size:0.73rem;color:var(--blue-dark);"><?= $file ?></div>
                <div style="font-size:0.75rem;color:var(--gray-500);"><?= $desc ?></div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
