<?php
// login.php
session_start();

if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
    header('Location: dashboard.php');
    exit();
}

require_once 'config/Database.php';
require_once 'classes/Auth.php';

$db    = (new Database())->getConnection();
$auth  = new Auth($db);
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password']      ?? '';

    if (empty($username) || empty($password)) {
        $error = 'Please enter both username and password.';
    } else {
        if ($auth->login($username, $password)) {
            header('Location: dashboard.php');
            exit();
        } else {
            $error = 'Invalid username or password. Please try again.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sign In — SmartOrder</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/style.css" rel="stylesheet">
</head>
<body>

<div class="login-page">
  <!-- Decorative background -->
  <div class="login-dots"></div>
  <div class="login-blob login-blob-1"></div>
  <div class="login-blob login-blob-2"></div>
  <div class="login-blob login-blob-3"></div>

  <!-- Card -->
  <div class="login-card">
    <div class="login-logo"><i class="bi bi-box-seam-fill"></i></div>
    <div class="login-title">SmartOrder</div>
    <div class="login-sub">Sign in to the Management System</div>

    <?php if (!empty($error)): ?>
      <div class="alert alert-danger mb-3" role="alert">
        <i class="bi bi-exclamation-circle-fill flex-shrink-0"></i>
        <span><?= htmlspecialchars($error) ?></span>
      </div>
    <?php endif; ?>

    <form method="POST" action="login.php" novalidate>
      <!-- Username -->
      <div class="mb-3">
        <label class="form-label" for="username">Username</label>
        <div class="input-group">
          <span class="input-group-text"><i class="bi bi-person"></i></span>
          <input
            type="text"
            id="username"
            name="username"
            class="form-control"
            placeholder="Enter your username"
            value="<?= htmlspecialchars($_POST['username'] ?? '') ?>"
            autocomplete="username"
            required
          >
        </div>
      </div>

      <!-- Password -->
      <div class="mb-3">
        <label class="form-label" for="passwordInput">Password</label>
        <div class="input-group">
          <span class="input-group-text"><i class="bi bi-lock"></i></span>
          <input
            type="password"
            id="passwordInput"
            name="password"
            class="form-control"
            placeholder="Enter your password"
            autocomplete="current-password"
            required
          >
          <button type="button" class="input-group-text" id="pwToggle" aria-label="Toggle password visibility">
            <i class="bi bi-eye" id="pwEye"></i>
          </button>
        </div>
      </div>

      <button type="submit" class="login-btn">
        <i class="bi bi-box-arrow-in-right me-2"></i>Sign In
      </button>
    </form>

    <div class="login-hint">
      <strong><i class="bi bi-info-circle me-1"></i>Demo Credentials</strong>
      Admin: <code>admin</code> / <code>password</code><br>
      Staff:&nbsp; <code>staff1</code> / <code>password</code>
    </div>
  </div>
</div>

<script>
  document.getElementById('pwToggle').addEventListener('click', function () {
    var inp  = document.getElementById('passwordInput');
    var icon = document.getElementById('pwEye');
    var isHidden = inp.type === 'password';
    inp.type       = isHidden ? 'text'      : 'password';
    icon.className = isHidden ? 'bi bi-eye-slash' : 'bi bi-eye';
    this.setAttribute('aria-label', isHidden ? 'Hide password' : 'Show password');
  });
</script>
</body>
</html>
