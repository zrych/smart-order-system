<?php
// customers_edit.php
require_once 'includes/session_check.php';
require_once 'config/Database.php';
require_once 'classes/Customer.php';

$db       = (new Database())->getConnection();
$customer = new Customer($db);

$id = (int)($_GET['id'] ?? 0);
if (!$id) { header('Location: customers.php'); exit(); }

$record = $customer->getById($id);
if (!$record) { header('Location: customers.php'); exit(); }

$errors   = [];
$formData = $record;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $formData['name']    = trim($_POST['name']    ?? '');
    $formData['email']   = trim($_POST['email']   ?? '');
    $formData['phone']   = trim($_POST['phone']   ?? '');
    $formData['address'] = trim($_POST['address'] ?? '');

    if (empty($formData['name'])) $errors[] = 'Customer name is required.';
    if (!empty($formData['email']) && !filter_var($formData['email'], FILTER_VALIDATE_EMAIL))
        $errors[] = 'Please enter a valid email address.';

    if (empty($errors)) {
        $customer->id      = $id;
        $customer->name    = $formData['name'];
        $customer->email   = $formData['email'];
        $customer->phone   = $formData['phone'];
        $customer->address = $formData['address'];

        if ($customer->update()) {
            header('Location: customers.php?success=updated');
            exit();
        } else {
            $errors[] = 'Failed to update customer.';
        }
    }
}

$pageTitle  = 'Edit Customer';
$activePage = 'customers';
include 'includes/header.php';
?>

<div class="page-header">
    <div>
        <h1><i class="bi bi-pencil-square me-2" style="color:var(--red);"></i>Edit Customer</h1>
        <p>Editing: <strong><?= htmlspecialchars($record['name']) ?></strong></p>
    </div>
    <a href="customers.php" class="btn-secondary-custom">
        <i class="bi bi-arrow-left"></i> Back to Customers
    </a>
</div>

<?php if (!empty($errors)): ?>
    <div class="alert alert-danger mb-3">
        <?php foreach ($errors as $e): ?>
            <div><i class="bi bi-exclamation-circle-fill me-1"></i><?= htmlspecialchars($e) ?></div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<div class="form-card">
    <form method="POST" novalidate>
        <div class="mb-3">
            <label class="form-label">Full Name <span style="color:var(--red)">*</span></label>
            <input type="text" name="name" class="form-control"
                   value="<?= htmlspecialchars($formData['name']) ?>" required>
        </div>
        <div class="row g-3">
            <div class="col-md-6">
                <label class="form-label">Email Address</label>
                <input type="email" name="email" class="form-control"
                       value="<?= htmlspecialchars($formData['email'] ?? '') ?>">
            </div>
            <div class="col-md-6">
                <label class="form-label">Phone Number</label>
                <input type="text" name="phone" class="form-control"
                       value="<?= htmlspecialchars($formData['phone'] ?? '') ?>">
            </div>
        </div>
        <div class="mt-3 mb-4">
            <label class="form-label">Address</label>
            <textarea name="address" class="form-control" rows="3"><?= htmlspecialchars($formData['address'] ?? '') ?></textarea>
        </div>
        <div class="d-flex gap-2">
            <button type="submit" class="btn-primary-custom">
                <i class="bi bi-check-lg"></i> Update Customer
            </button>
            <a href="customers.php" class="btn-secondary-custom">
                <i class="bi bi-x-lg"></i> Cancel
            </a>
        </div>
    </form>
</div>

<?php include 'includes/footer.php'; ?>
