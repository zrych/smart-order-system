<?php
// orders.php
require_once 'includes/session_check.php';
require_once 'config/Database.php';
require_once 'classes/Order.php';

$db     = (new Database())->getConnection();
$order  = new Order($db);
$orders = $order->getAll();

$success    = $_GET['success'] ?? '';
$pageTitle  = 'Orders';
$activePage = 'orders';
include 'includes/header.php';
?>

<?php if ($success === 'created'): ?>
    <div class="alert alert-success alert-dismissible alert-auto-dismiss mb-3">
        <i class="bi bi-check-circle-fill me-2"></i> Order created successfully!
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php elseif ($success === 'updated'): ?>
    <div class="alert alert-success alert-dismissible alert-auto-dismiss mb-3">
        <i class="bi bi-check-circle-fill me-2"></i> Order updated successfully!
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php elseif ($success === 'deleted'): ?>
    <div class="alert alert-danger alert-dismissible alert-auto-dismiss mb-3">
        <i class="bi bi-trash-fill me-2"></i> Order deleted.
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<div class="page-header">
    <div>
        <h1><i class="bi bi-cart-fill me-2" style="color:var(--red);"></i>Orders</h1>
        <p><?= count($orders) ?> order(s) — linked to customers and staff via JOIN</p>
    </div>
    <a href="orders_add.php" class="btn-primary-custom">
        <i class="bi bi-plus-lg"></i> New Order
    </a>
</div>

<div class="table-wrapper">
    <?php if (empty($orders)): ?>
        <div class="empty-state">
            <i class="bi bi-cart-x"></i>
            <p>No orders yet. <a href="orders_add.php">Create the first order.</a></p>
        </div>
    <?php else: ?>
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Customer Name</th>
                    <th>Product</th>
                    <th>Qty</th>
                    <th>Price</th>
                    <th>Total</th>
                    <th>Status</th>
                    <th>Created By</th>
                    <th>Date</th>
                    <th class="text-center">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($orders as $o): ?>
                <tr>
                    <td><span style="font-family:'Space Mono',monospace;font-size:0.78rem;color:var(--gray-400);">#<?= str_pad($o['id'], 4, '0', STR_PAD_LEFT) ?></span></td>
                    <td>
                        <div style="font-weight:600;"><?= htmlspecialchars($o['customer_name']) ?></div>
                        <div style="font-size:0.73rem;color:var(--gray-400);"><?= htmlspecialchars($o['customer_email'] ?: '') ?></div>
                    </td>
                    <td><?= htmlspecialchars($o['product']) ?></td>
                    <td><?= $o['quantity'] ?></td>
                    <td>₱<?= number_format($o['price'], 2) ?></td>
                    <td><strong>₱<?= number_format($o['total_amount'], 2) ?></strong></td>
                    <td>
                        <span class="status-badge status-<?= $o['status'] ?>">
                            <?= ucfirst($o['status']) ?>
                        </span>
                    </td>
                    <td>
                        <div style="font-size:0.82rem;"><?= htmlspecialchars($o['created_by']) ?></div>
                        <div style="font-size:0.72rem;color:var(--gray-400);">@<?= htmlspecialchars($o['staff_username']) ?></div>
                    </td>
                    <td style="font-size:0.78rem;color:var(--gray-400);"><?= date('M d, Y', strtotime($o['created_at'])) ?></td>
                    <td class="text-center">
                        <div class="d-flex gap-1 justify-content-center">
                            <a href="orders_edit.php?id=<?= $o['id'] ?>" class="btn-action btn-edit" title="Edit">
                                <i class="bi bi-pencil-fill"></i>
                            </a>
                            <a href="orders_delete.php?id=<?= $o['id'] ?>"
                               class="btn-action btn-delete"
                               title="Delete"
                               onclick="return confirm('Delete this order?')">
                                <i class="bi bi-trash-fill"></i>
                            </a>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>
