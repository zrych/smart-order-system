<?php
// reports.php
require_once 'includes/session_check.php';
require_once 'config/Database.php';
require_once 'classes/Order.php';
require_once 'classes/Customer.php';

$db       = (new Database())->getConnection();
$order    = new Order($db);
$customer = new Customer($db);

// All orders with full JOIN
$orders = $order->getAll();

// Stats
$totalRevenue     = $order->totalRevenue();
$totalOrders      = $order->count();
$completedOrders  = $order->countByStatus('completed');
$pendingOrders    = $order->countByStatus('pending');
$totalCustomers   = $customer->count();

// Revenue by status
$statusTotals = [];
foreach ($orders as $o) {
    $s = $o['status'];
    if (!isset($statusTotals[$s])) $statusTotals[$s] = ['count' => 0, 'revenue' => 0];
    $statusTotals[$s]['count']++;
    $statusTotals[$s]['revenue'] += $o['total_amount'];
}

// Revenue per customer (top customers)
$customerRevenue = [];
foreach ($orders as $o) {
    $cn = $o['customer_name'];
    if (!isset($customerRevenue[$cn])) $customerRevenue[$cn] = ['orders' => 0, 'total' => 0];
    $customerRevenue[$cn]['orders']++;
    $customerRevenue[$cn]['total'] += $o['total_amount'];
}
arsort($customerRevenue);

$pageTitle  = 'Reports';
$activePage = 'reports';
include 'includes/header.php';
?>

<div class="report-header">
    <div class="report-icon"><i class="bi bi-bar-chart-fill"></i></div>
    <div>
        <div class="report-title">Transaction Reports</div>
        <div class="report-sub">Live data pulled using JOIN across customers, orders, and users tables</div>
    </div>
</div>

<!-- Summary Stats -->
<div class="row g-3 mb-4">
    <div class="col-sm-6 col-xl-3">
        <div class="stat-card">
            <div class="stat-icon green"><i class="bi bi-cash-stack"></i></div>
            <div>
                <div class="stat-label">Total Revenue</div>
                <div class="stat-value">₱<?= number_format($totalRevenue, 0) ?></div>
                <div class="stat-sub">Completed orders only</div>
            </div>
        </div>
    </div>
    <div class="col-sm-6 col-xl-3">
        <div class="stat-card">
            <div class="stat-icon red"><i class="bi bi-receipt"></i></div>
            <div>
                <div class="stat-label">Total Orders</div>
                <div class="stat-value"><?= $totalOrders ?></div>
                <div class="stat-sub"><?= $completedOrders ?> completed</div>
            </div>
        </div>
    </div>
    <div class="col-sm-6 col-xl-3">
        <div class="stat-card">
            <div class="stat-icon blue"><i class="bi bi-people-fill"></i></div>
            <div>
                <div class="stat-label">Customers</div>
                <div class="stat-value"><?= $totalCustomers ?></div>
                <div class="stat-sub">With order history</div>
            </div>
        </div>
    </div>
    <div class="col-sm-6 col-xl-3">
        <div class="stat-card">
            <div class="stat-icon black"><i class="bi bi-hourglass-split"></i></div>
            <div>
                <div class="stat-label">Pending</div>
                <div class="stat-value"><?= $pendingOrders ?></div>
                <div class="stat-sub">Awaiting processing</div>
            </div>
        </div>
    </div>
</div>

<div class="row g-4">
    <!-- Full Transaction Report (JOIN) -->
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <i class="bi bi-table"></i>
                Full Transaction Report
                <span style="font-size:0.75rem;font-weight:400;color:var(--gray-400);margin-left:8px;">
                    — Orders JOIN Customers JOIN Users
                </span>
            </div>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Order ID</th>
                            <th>Customer Name</th>
                            <th>Product</th>
                            <th>Qty</th>
                            <th>Unit Price</th>
                            <th>Total</th>
                            <th>Status</th>
                            <th>Created By</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($orders)): ?>
                        <tr>
                            <td colspan="9" class="text-center" style="padding:30px;color:var(--gray-400);">
                                No transactions recorded yet.
                            </td>
                        </tr>
                        <?php else: ?>
                        <?php foreach ($orders as $o): ?>
                        <tr>
                            <td><span style="font-family:'Space Mono',monospace;font-size:0.78rem;">#<?= str_pad($o['id'], 4, '0', STR_PAD_LEFT) ?></span></td>
                            <td><strong><?= htmlspecialchars($o['customer_name']) ?></strong></td>
                            <td><?= htmlspecialchars($o['product']) ?></td>
                            <td><?= $o['quantity'] ?></td>
                            <td>₱<?= number_format($o['price'], 2) ?></td>
                            <td><strong>₱<?= number_format($o['total_amount'], 2) ?></strong></td>
                            <td><span class="status-badge status-<?= $o['status'] ?>"><?= ucfirst($o['status']) ?></span></td>
                            <td><?= htmlspecialchars($o['created_by']) ?></td>
                            <td style="font-size:0.78rem;color:var(--gray-400);"><?= date('M d, Y', strtotime($o['created_at'])) ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                    <?php if (!empty($orders)): ?>
                    <tfoot>
                        <tr style="background:var(--gray-100);">
                            <td colspan="5" style="font-weight:700;padding:12px 16px;font-size:0.85rem;">Grand Total (All Orders)</td>
                            <td style="font-weight:700;font-family:'Space Mono',monospace;padding:12px 16px;">
                                ₱<?= number_format(array_sum(array_column($orders, 'total_amount')), 2) ?>
                            </td>
                            <td colspan="3"></td>
                        </tr>
                    </tfoot>
                    <?php endif; ?>
                </table>
            </div>
        </div>
    </div>

    <!-- Status Breakdown -->
    <div class="col-md-6">
        <div class="card h-100">
            <div class="card-header"><i class="bi bi-pie-chart-fill"></i> Orders by Status</div>
            <div class="card-body p-0">
                <table class="table mb-0">
                    <thead>
                        <tr>
                            <th>Status</th>
                            <th>Count</th>
                            <th>Revenue</th>
                            <th>% of Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach (['pending','processing','completed','cancelled'] as $s): ?>
                        <?php $data = $statusTotals[$s] ?? ['count'=>0,'revenue'=>0]; ?>
                        <tr>
                            <td><span class="status-badge status-<?= $s ?>"><?= ucfirst($s) ?></span></td>
                            <td><?= $data['count'] ?></td>
                            <td>₱<?= number_format($data['revenue'], 2) ?></td>
                            <td>
                                <?php $pct = $totalOrders > 0 ? round($data['count'] / $totalOrders * 100) : 0; ?>
                                <div class="d-flex align-items-center gap-2">
                                    <div style="flex:1;height:6px;background:var(--gray-200);border-radius:3px;">
                                        <div style="width:<?= $pct ?>%;height:100%;background:var(--red);border-radius:3px;"></div>
                                    </div>
                                    <span style="font-size:0.75rem;color:var(--gray-600);width:32px;"><?= $pct ?>%</span>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Top Customers -->
    <div class="col-md-6">
        <div class="card h-100">
            <div class="card-header"><i class="bi bi-trophy-fill"></i> Top Customers by Revenue</div>
            <div class="card-body p-0">
                <?php if (empty($customerRevenue)): ?>
                    <div class="empty-state"><p>No data yet.</p></div>
                <?php else: ?>
                <table class="table mb-0">
                    <thead>
                        <tr>
                            <th>Customer</th>
                            <th>Orders</th>
                            <th>Total Spent</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($customerRevenue as $name => $data): ?>
                        <tr>
                            <td><strong><?= htmlspecialchars($name) ?></strong></td>
                            <td><?= $data['orders'] ?></td>
                            <td>
                                <span style="font-family:'Space Mono',monospace;font-size:0.82rem;font-weight:700;color:var(--black-soft);">
                                    ₱<?= number_format($data['total'], 2) ?>
                                </span>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
