<?php
// config/Database.php
class Database {
    private $host     = 'localhost';
    private $db_name  = 'smart_order_db';
    private $username = 'root';
    private $password = '';
    private $conn;

    public function getConnection() {
        $this->conn = null;
        try {
            $this->conn = new PDO(
                "mysql:host={$this->host};dbname={$this->db_name};charset=utf8",
                $this->username,
                $this->password
            );
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            die("<div style='font-family:sans-serif;padding:20px;background:#ffe0e0;border:1px solid #ff6b6b;border-radius:8px;'>
                    <strong>Database Connection Error:</strong> " . htmlspecialchars($e->getMessage()) . "
                    <br><br><small>Make sure XAMPP MySQL is running and the database exists.</small>
                 </div>");
        }
        return $this->conn;
    }
}
