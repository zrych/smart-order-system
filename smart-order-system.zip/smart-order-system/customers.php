<?php
// customers.php
require_once 'includes/session_check.php';
require_once 'config/Database.php';
require_once 'classes/Customer.php';

$db       = (new Database())->getConnection();
$customer = new Customer($db);
$customers = $customer->getAll();

$success = $_GET['success'] ?? '';
$pageTitle  = 'Customers';
$activePage = 'customers';
include 'includes/header.php';
?>

<?php if ($success === 'created'): ?>
    <div class="alert alert-success alert-dismissible alert-auto-dismiss mb-3">
        <i class="bi bi-check-circle-fill me-2"></i> Customer added successfully!
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php elseif ($success === 'updated'): ?>
    <div class="alert alert-success alert-dismissible alert-auto-dismiss mb-3">
        <i class="bi bi-check-circle-fill me-2"></i> Customer updated successfully!
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php elseif ($success === 'deleted'): ?>
    <div class="alert alert-danger alert-dismissible alert-auto-dismiss mb-3">
        <i class="bi bi-trash-fill me-2"></i> Customer deleted successfully!
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<div class="page-header">
    <div>
        <h1><i class="bi bi-people-fill me-2" style="color:var(--red);"></i>Customers</h1>
        <p><?= count($customers) ?> customer(s) registered in the system</p>
    </div>
    <a href="customers_add.php" class="btn-primary-custom">
        <i class="bi bi-plus-lg"></i> Add Customer
    </a>
</div>

<div class="table-wrapper">
    <?php if (empty($customers)): ?>
        <div class="empty-state">
            <i class="bi bi-people"></i>
            <p>No customers yet. <a href="customers_add.php">Add the first customer.</a></p>
        </div>
    <?php else: ?>
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Address</th>
                    <th>Added By</th>
                    <th>Date Added</th>
                    <th class="text-center">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($customers as $i => $c): ?>
                <tr>
                    <td style="font-family:'Space Mono',monospace;font-size:0.78rem;color:var(--gray-400);"><?= str_pad($c['id'], 3, '0', STR_PAD_LEFT) ?></td>
                    <td>
                        <div style="font-weight:600;"><?= htmlspecialchars($c['name']) ?></div>
                    </td>
                    <td><?= htmlspecialchars($c['email'] ?: '—') ?></td>
                    <td><?= htmlspecialchars($c['phone'] ?: '—') ?></td>
                    <td style="max-width:180px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
                        <?= htmlspecialchars($c['address'] ?: '—') ?>
                    </td>
                    <td>
                        <span style="font-size:0.8rem;padding:2px 8px;background:var(--blue-bg);color:var(--blue-dark);border-radius:4px;">
                            <?= htmlspecialchars($c['created_by_name'] ?? 'N/A') ?>
                        </span>
                    </td>
                    <td style="font-size:0.78rem;color:var(--gray-400);"><?= date('M d, Y', strtotime($c['created_at'])) ?></td>
                    <td class="text-center">
                        <div class="d-flex gap-1 justify-content-center">
                            <a href="customers_edit.php?id=<?= $c['id'] ?>" class="btn-action btn-edit" title="Edit">
                                <i class="bi bi-pencil-fill"></i>
                            </a>
                            <a href="customers_delete.php?id=<?= $c['id'] ?>"
                               class="btn-action btn-delete"
                               title="Delete"
                               onclick="return confirm('Delete this customer? All their orders will also be deleted.')">
                                <i class="bi bi-trash-fill"></i>
                            </a>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>
