<?php
// orders_add.php
require_once 'includes/session_check.php';
require_once 'config/Database.php';
require_once 'classes/Order.php';
require_once 'classes/Customer.php';

$db       = (new Database())->getConnection();
$order    = new Order($db);
$customer = new Customer($db);
$customers = $customer->getAllSimple();

$errors   = [];
$formData = ['customer_id'=>'','product'=>'','quantity'=>1,'price'=>'','status'=>'pending','notes'=>''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $formData['customer_id'] = (int)($_POST['customer_id'] ?? 0);
    $formData['product']     = trim($_POST['product']     ?? '');
    $formData['quantity']    = (int)($_POST['quantity']   ?? 1);
    $formData['price']       = trim($_POST['price']       ?? '');
    $formData['status']      = trim($_POST['status']      ?? 'pending');
    $formData['notes']       = trim($_POST['notes']       ?? '');

    if (!$formData['customer_id'])            $errors[] = 'Please select a customer.';
    if (empty($formData['product']))          $errors[] = 'Product name is required.';
    if ($formData['quantity'] < 1)            $errors[] = 'Quantity must be at least 1.';
    if (!is_numeric($formData['price']) || $formData['price'] < 0)
                                              $errors[] = 'Please enter a valid price.';

    if (empty($errors)) {
        $order->customer_id = $formData['customer_id'];
        $order->user_id     = $currentUser['id'];
        $order->product     = $formData['product'];
        $order->quantity    = $formData['quantity'];
        $order->price       = $formData['price'];
        $order->status      = $formData['status'];
        $order->notes       = $formData['notes'];

        if ($order->create()) {
            header('Location: orders.php?success=created');
            exit();
        } else {
            $errors[] = 'Failed to create order. Please try again.';
        }
    }
}

$pageTitle  = 'New Order';
$activePage = 'orders';
include 'includes/header.php';
?>

<div class="page-header">
    <div>
        <h1><i class="bi bi-cart-plus-fill me-2" style="color:var(--red);"></i>New Order</h1>
        <p>Create a new order transaction — recorded under your account</p>
    </div>
    <a href="orders.php" class="btn-secondary-custom">
        <i class="bi bi-arrow-left"></i> Back to Orders
    </a>
</div>

<?php if (!empty($errors)): ?>
    <div class="alert alert-danger mb-3">
        <?php foreach ($errors as $e): ?>
            <div><i class="bi bi-exclamation-circle-fill me-1"></i><?= htmlspecialchars($e) ?></div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<div class="form-card">
    <!-- Transaction info banner -->
    <div style="background:var(--blue-bg);border-radius:8px;padding:12px 16px;margin-bottom:24px;border-left:4px solid var(--blue);">
        <div style="font-size:0.82rem;color:var(--blue-dark);">
            <i class="bi bi-info-circle-fill me-2"></i>
            This order will be recorded as created by <strong><?= htmlspecialchars($currentUser['full_name']) ?></strong>
            (@<?= htmlspecialchars($currentUser['username']) ?>)
        </div>
    </div>

    <form method="POST" novalidate>
        <div class="mb-3">
            <label class="form-label">Customer <span style="color:var(--red)">*</span></label>
            <?php if (empty($customers)): ?>
                <div class="alert alert-danger">
                    No customers found. <a href="customers_add.php">Add a customer first</a>.
                </div>
            <?php else: ?>
            <select name="customer_id" class="form-select" required>
                <option value="">— Select Customer —</option>
                <?php foreach ($customers as $c): ?>
                    <option value="<?= $c['id'] ?>"
                        <?= $formData['customer_id'] == $c['id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($c['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <?php endif; ?>
        </div>

        <div class="mb-3">
            <label class="form-label">Product / Item <span style="color:var(--red)">*</span></label>
            <input type="text" name="product" class="form-control"
                   placeholder="e.g. Mechanical Keyboard"
                   value="<?= htmlspecialchars($formData['product']) ?>" required>
        </div>

        <div class="row g-3">
            <div class="col-md-4">
                <label class="form-label">Quantity <span style="color:var(--red)">*</span></label>
                <input type="number" name="quantity" class="form-control"
                       min="1" value="<?= htmlspecialchars($formData['quantity']) ?>" required>
            </div>
            <div class="col-md-4">
                <label class="form-label">Unit Price (₱) <span style="color:var(--red)">*</span></label>
                <input type="number" name="price" class="form-control"
                       min="0" step="0.01" placeholder="0.00"
                       value="<?= htmlspecialchars($formData['price']) ?>" required>
            </div>
            <div class="col-md-4">
                <label class="form-label">Status</label>
                <select name="status" class="form-select">
                    <option value="pending"    <?= $formData['status']==='pending'    ? 'selected':'' ?>>Pending</option>
                    <option value="processing" <?= $formData['status']==='processing' ? 'selected':'' ?>>Processing</option>
                    <option value="completed"  <?= $formData['status']==='completed'  ? 'selected':'' ?>>Completed</option>
                    <option value="cancelled"  <?= $formData['status']==='cancelled'  ? 'selected':'' ?>>Cancelled</option>
                </select>
            </div>
        </div>

        <div class="mt-3 mb-4">
            <label class="form-label">Notes <span style="font-weight:400;color:var(--gray-400)">(optional)</span></label>
            <textarea name="notes" class="form-control" rows="3"
                      placeholder="Special instructions or remarks..."><?= htmlspecialchars($formData['notes']) ?></textarea>
        </div>

        <!-- Live total preview -->
        <div id="totalPreview" style="background:var(--gray-100);border-radius:8px;padding:12px 16px;margin-bottom:20px;display:none;">
            <span style="font-size:0.85rem;color:var(--gray-600);">Estimated Total:</span>
            <span id="totalAmount" style="font-family:'Space Mono',monospace;font-size:1.1rem;font-weight:700;color:var(--black-soft);margin-left:8px;"></span>
        </div>

        <div class="d-flex gap-2">
            <button type="submit" class="btn-primary-custom" <?= empty($customers) ? 'disabled' : '' ?>>
                <i class="bi bi-check-lg"></i> Create Order
            </button>
            <a href="orders.php" class="btn-secondary-custom">
                <i class="bi bi-x-lg"></i> Cancel
            </a>
        </div>
    </form>
</div>

<script>
    const qtyInput   = document.querySelector('[name="quantity"]');
    const priceInput = document.querySelector('[name="price"]');
    const preview    = document.getElementById('totalPreview');
    const total      = document.getElementById('totalAmount');

    function updateTotal() {
        const qty   = parseFloat(qtyInput.value)   || 0;
        const price = parseFloat(priceInput.value) || 0;
        if (qty > 0 && price > 0) {
            preview.style.display = 'block';
            total.textContent = '₱' + (qty * price).toLocaleString('en-PH', {minimumFractionDigits: 2});
        } else {
            preview.style.display = 'none';
        }
    }
    qtyInput.addEventListener('input', updateTotal);
    priceInput.addEventListener('input', updateTotal);
</script>

<?php include 'includes/footer.php'; ?>
