<?php
// dashboard.php
require_once 'includes/session_check.php';
require_once 'config/Database.php';
require_once 'classes/Customer.php';
require_once 'classes/Order.php';
require_once 'classes/User.php';

$db       = (new Database())->getConnection();
$customer = new Customer($db);
$order    = new Order($db);
$user     = new User($db);

$totalCustomers  = $customer->count();
$totalOrders     = $order->count();
$totalUsers      = $user->count();
$totalRevenue    = $order->totalRevenue();
$pendingOrders   = $order->countByStatus('pending');
$completedOrders = $order->countByStatus('completed');
$recentOrders    = $order->getRecent(6);

$pageTitle  = 'Dashboard';
$activePage = 'dashboard';
include 'includes/header.php';
?>

<!-- Stat Cards -->
<div class="row g-3 mb-4">
    <div class="col-sm-6 col-xl-3">
        <div class="stat-card">
            <div class="stat-icon blue"><i class="bi bi-people-fill"></i></div>
            <div>
                <div class="stat-label">Total Customers</div>
                <div class="stat-value"><?= $totalCustomers ?></div>
                <div class="stat-sub">Registered customers</div>
            </div>
        </div>
    </div>
    <div class="col-sm-6 col-xl-3">
        <div class="stat-card">
            <div class="stat-icon red"><i class="bi bi-cart-fill"></i></div>
            <div>
                <div class="stat-label">Total Orders</div>
                <div class="stat-value"><?= $totalOrders ?></div>
                <div class="stat-sub"><?= $pendingOrders ?> pending</div>
            </div>
        </div>
    </div>
    <div class="col-sm-6 col-xl-3">
        <div class="stat-card">
            <div class="stat-icon green"><i class="bi bi-cash-stack"></i></div>
            <div>
                <div class="stat-label">Revenue</div>
                <div class="stat-value">₱<?= number_format($totalRevenue, 0) ?></div>
                <div class="stat-sub">From completed orders</div>
            </div>
        </div>
    </div>
    <div class="col-sm-6 col-xl-3">
        <div class="stat-card">
            <div class="stat-icon black"><i class="bi bi-shield-person-fill"></i></div>
            <div>
                <div class="stat-label">Staff Members</div>
                <div class="stat-value"><?= $totalUsers ?></div>
                <div class="stat-sub">Active system users</div>
            </div>
        </div>
    </div>
</div>

<!-- Order Status Row -->
<div class="row g-3 mb-4">
    <div class="col-md-3 col-6">
        <div class="card text-center p-3">
            <div style="font-size:1.5rem;font-weight:800;color:#b45309;font-family:'Space Mono',monospace;"><?= $order->countByStatus('pending') ?></div>
            <div class="status-badge status-pending mx-auto mt-1">Pending</div>
        </div>
    </div>
    <div class="col-md-3 col-6">
        <div class="card text-center p-3">
            <div style="font-size:1.5rem;font-weight:800;color:var(--blue-dark);font-family:'Space Mono',monospace;"><?= $order->countByStatus('processing') ?></div>
            <div class="status-badge status-processing mx-auto mt-1">Processing</div>
        </div>
    </div>
    <div class="col-md-3 col-6">
        <div class="card text-center p-3">
            <div style="font-size:1.5rem;font-weight:800;color:#2d8a4e;font-family:'Space Mono',monospace;"><?= $order->countByStatus('completed') ?></div>
            <div class="status-badge status-completed mx-auto mt-1">Completed</div>
        </div>
    </div>
    <div class="col-md-3 col-6">
        <div class="card text-center p-3">
            <div style="font-size:1.5rem;font-weight:800;color:var(--red-dark);font-family:'Space Mono',monospace;"><?= $order->countByStatus('cancelled') ?></div>
            <div class="status-badge status-cancelled mx-auto mt-1">Cancelled</div>
        </div>
    </div>
</div>

<!-- Recent Orders Table -->
<div class="card">
    <div class="card-header">
        <i class="bi bi-clock-history"></i>
        Recent Orders
        <a href="orders.php" class="btn-secondary-custom ms-auto" style="font-size:0.78rem;padding:5px 12px;">
            View All <i class="bi bi-arrow-right"></i>
        </a>
    </div>
    <div class="table-responsive">
        <?php if (empty($recentOrders)): ?>
            <div class="empty-state">
                <i class="bi bi-cart-x"></i>
                <p>No orders yet. <a href="orders_add.php">Create the first order.</a></p>
            </div>
        <?php else: ?>
        <table class="table">
            <thead>
                <tr>
                    <th>#ID</th>
                    <th>Customer</th>
                    <th>Product</th>
                    <th>Qty</th>
                    <th>Total</th>
                    <th>Status</th>
                    <th>Created By</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($recentOrders as $ord): ?>
                <tr>
                    <td><span style="font-family:'Space Mono',monospace;font-size:0.78rem;color:var(--gray-400);">#<?= str_pad($ord['id'], 4, '0', STR_PAD_LEFT) ?></span></td>
                    <td><strong><?= htmlspecialchars($ord['customer_name']) ?></strong></td>
                    <td><?= htmlspecialchars($ord['product']) ?></td>
                    <td><?= $ord['quantity'] ?></td>
                    <td><strong>₱<?= number_format($ord['total_amount'], 2) ?></strong></td>
                    <td>
                        <span class="status-badge status-<?= $ord['status'] ?>">
                            <?= ucfirst($ord['status']) ?>
                        </span>
                    </td>
                    <td><?= htmlspecialchars($ord['created_by']) ?></td>
                    <td style="font-size:0.78rem;color:var(--gray-400);"><?= date('M d, Y', strtotime($ord['created_at'])) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
