<?php
// users_edit.php
require_once 'includes/session_check.php';
if (!Auth::isAdmin()) { header('Location: dashboard.php'); exit(); }
require_once 'config/Database.php';
require_once 'classes/User.php';

$db   = (new Database())->getConnection();
$user = new User($db);

$id = (int)($_GET['id'] ?? 0);
if (!$id) { header('Location: users.php'); exit(); }

$record = $user->getById($id);
if (!$record) { header('Location: users.php'); exit(); }

$errors   = [];
$formData = $record;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $formData['username']  = trim($_POST['username']  ?? '');
    $formData['full_name'] = trim($_POST['full_name'] ?? '');
    $formData['email']     = trim($_POST['email']     ?? '');
    $formData['role']      = trim($_POST['role']      ?? 'staff');
    $password              = $_POST['password']        ?? '';
    $confirmPassword       = $_POST['confirm_password'] ?? '';

    if (empty($formData['username']))  $errors[] = 'Username is required.';
    if (empty($formData['full_name'])) $errors[] = 'Full name is required.';
    if (empty($formData['email']))     $errors[] = 'Email is required.';
    if (!filter_var($formData['email'], FILTER_VALIDATE_EMAIL)) $errors[] = 'Invalid email format.';
    if (!empty($password) && strlen($password) < 6) $errors[] = 'Password must be at least 6 characters.';
    if (!empty($password) && $password !== $confirmPassword) $errors[] = 'Passwords do not match.';
    if ($user->usernameExists($formData['username'], $id)) $errors[] = 'Username already taken.';

    if (empty($errors)) {
        $user->id        = $id;
        $user->username  = $formData['username'];
        $user->full_name = $formData['full_name'];
        $user->email     = $formData['email'];
        $user->password  = $password;
        $user->role      = $formData['role'];

        if ($user->update()) {
            header('Location: users.php?success=updated');
            exit();
        } else {
            $errors[] = 'Failed to update user.';
        }
    }
}

$pageTitle  = 'Edit User';
$activePage = 'users';
include 'includes/header.php';
?>

<div class="page-header">
    <div>
        <h1><i class="bi bi-person-gear me-2" style="color:var(--red);"></i>Edit User</h1>
        <p>Editing: <strong><?= htmlspecialchars($record['full_name']) ?></strong></p>
    </div>
    <a href="users.php" class="btn-secondary-custom"><i class="bi bi-arrow-left"></i> Back</a>
</div>

<?php if (!empty($errors)): ?>
    <div class="alert alert-danger mb-3">
        <?php foreach ($errors as $e): ?>
            <div><i class="bi bi-exclamation-circle-fill me-1"></i><?= htmlspecialchars($e) ?></div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<div class="form-card">
    <form method="POST" novalidate>
        <div class="row g-3">
            <div class="col-md-6">
                <label class="form-label">Username <span style="color:var(--red)">*</span></label>
                <input type="text" name="username" class="form-control"
                       value="<?= htmlspecialchars($formData['username']) ?>" required>
            </div>
            <div class="col-md-6">
                <label class="form-label">Full Name <span style="color:var(--red)">*</span></label>
                <input type="text" name="full_name" class="form-control"
                       value="<?= htmlspecialchars($formData['full_name']) ?>" required>
            </div>
        </div>
        <div class="row g-3 mt-1">
            <div class="col-md-6">
                <label class="form-label">Email <span style="color:var(--red)">*</span></label>
                <input type="email" name="email" class="form-control"
                       value="<?= htmlspecialchars($formData['email']) ?>" required>
            </div>
            <div class="col-md-6">
                <label class="form-label">Role</label>
                <select name="role" class="form-select">
                    <option value="staff" <?= $formData['role']==='staff' ? 'selected':'' ?>>Staff</option>
                    <option value="admin" <?= $formData['role']==='admin' ? 'selected':'' ?>>Admin</option>
                </select>
            </div>
        </div>
        <div class="row g-3 mt-1">
            <div class="col-md-6">
                <label class="form-label">New Password <span style="font-weight:400;color:var(--gray-400)">(leave blank to keep current)</span></label>
                <input type="password" name="password" class="form-control" placeholder="Min. 6 characters">
            </div>
            <div class="col-md-6">
                <label class="form-label">Confirm Password</label>
                <input type="password" name="confirm_password" class="form-control" placeholder="Repeat new password">
            </div>
        </div>
        <div class="d-flex gap-2 mt-4">
            <button type="submit" class="btn-primary-custom">
                <i class="bi bi-check-lg"></i> Update User
            </button>
            <a href="users.php" class="btn-secondary-custom">
                <i class="bi bi-x-lg"></i> Cancel
            </a>
        </div>
    </form>
</div>

<?php include 'includes/footer.php'; ?>
