<?php
// customers_delete.php
require_once 'includes/session_check.php';
require_once 'config/Database.php';
require_once 'classes/Customer.php';

$db       = (new Database())->getConnection();
$customer = new Customer($db);

$id = (int)($_GET['id'] ?? 0);
if ($id) {
    $customer->delete($id);
}
header('Location: customers.php?success=deleted');
exit();
