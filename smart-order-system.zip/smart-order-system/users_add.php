<?php
// users_add.php
require_once 'includes/session_check.php';
if (!Auth::isAdmin()) { header('Location: dashboard.php'); exit(); }
require_once 'config/Database.php';
require_once 'classes/User.php';

$db   = (new Database())->getConnection();
$user = new User($db);

$errors   = [];
$formData = ['username'=>'','full_name'=>'','email'=>'','role'=>'staff'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $formData['username']  = trim($_POST['username']  ?? '');
    $formData['full_name'] = trim($_POST['full_name'] ?? '');
    $formData['email']     = trim($_POST['email']     ?? '');
    $formData['role']      = trim($_POST['role']      ?? 'staff');
    $password              = $_POST['password']        ?? '';
    $confirmPassword       = $_POST['confirm_password'] ?? '';

    if (empty($formData['username']))  $errors[] = 'Username is required.';
    if (empty($formData['full_name'])) $errors[] = 'Full name is required.';
    if (empty($formData['email']))     $errors[] = 'Email is required.';
    if (!filter_var($formData['email'], FILTER_VALIDATE_EMAIL)) $errors[] = 'Invalid email format.';
    if (empty($password))              $errors[] = 'Password is required.';
    if (strlen($password) < 6)         $errors[] = 'Password must be at least 6 characters.';
    if ($password !== $confirmPassword) $errors[] = 'Passwords do not match.';
    if ($user->usernameExists($formData['username'])) $errors[] = 'Username already taken.';

    if (empty($errors)) {
        $user->username  = $formData['username'];
        $user->full_name = $formData['full_name'];
        $user->email     = $formData['email'];
        $user->password  = $password;
        $user->role      = $formData['role'];

        if ($user->create()) {
            header('Location: users.php?success=created');
            exit();
        } else {
            $errors[] = 'Failed to create user. Please try again.';
        }
    }
}

$pageTitle  = 'Add User';
$activePage = 'users';
include 'includes/header.php';
?>

<div class="page-header">
    <div>
        <h1><i class="bi bi-person-plus-fill me-2" style="color:var(--red);"></i>Add User</h1>
        <p>Create a new staff or admin account</p>
    </div>
    <a href="users.php" class="btn-secondary-custom"><i class="bi bi-arrow-left"></i> Back</a>
</div>

<?php if (!empty($errors)): ?>
    <div class="alert alert-danger mb-3">
        <?php foreach ($errors as $e): ?>
            <div><i class="bi bi-exclamation-circle-fill me-1"></i><?= htmlspecialchars($e) ?></div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<div class="form-card">
    <form method="POST" novalidate>
        <div class="row g-3">
            <div class="col-md-6">
                <label class="form-label">Username <span style="color:var(--red)">*</span></label>
                <input type="text" name="username" class="form-control"
                       placeholder="e.g. jdelacruz"
                       value="<?= htmlspecialchars($formData['username']) ?>" required>
            </div>
            <div class="col-md-6">
                <label class="form-label">Full Name <span style="color:var(--red)">*</span></label>
                <input type="text" name="full_name" class="form-control"
                       placeholder="e.g. Juan Dela Cruz"
                       value="<?= htmlspecialchars($formData['full_name']) ?>" required>
            </div>
        </div>

        <div class="row g-3 mt-1">
            <div class="col-md-6">
                <label class="form-label">Email <span style="color:var(--red)">*</span></label>
                <input type="email" name="email" class="form-control"
                       placeholder="e.g. juan@email.com"
                       value="<?= htmlspecialchars($formData['email']) ?>" required>
            </div>
            <div class="col-md-6">
                <label class="form-label">Role</label>
                <select name="role" class="form-select">
                    <option value="staff" <?= $formData['role']==='staff' ? 'selected':'' ?>>Staff</option>
                    <option value="admin" <?= $formData['role']==='admin' ? 'selected':'' ?>>Admin</option>
                </select>
            </div>
        </div>

        <div class="row g-3 mt-1">
            <div class="col-md-6">
                <label class="form-label">Password <span style="color:var(--red)">*</span></label>
                <input type="password" name="password" class="form-control"
                       placeholder="Min. 6 characters" required>
            </div>
            <div class="col-md-6">
                <label class="form-label">Confirm Password <span style="color:var(--red)">*</span></label>
                <input type="password" name="confirm_password" class="form-control"
                       placeholder="Repeat password" required>
            </div>
        </div>

        <div class="d-flex gap-2 mt-4">
            <button type="submit" class="btn-primary-custom">
                <i class="bi bi-check-lg"></i> Create User
            </button>
            <a href="users.php" class="btn-secondary-custom">
                <i class="bi bi-x-lg"></i> Cancel
            </a>
        </div>
    </form>
</div>

<?php include 'includes/footer.php'; ?>
