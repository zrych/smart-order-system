-- Smart Order Management System
-- Database: smart_order_db

CREATE DATABASE IF NOT EXISTS smart_order_db;
USE smart_order_db;

-- ==========================================
-- TABLE 1: users (Authentication)
-- ==========================================
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin','staff') DEFAULT 'staff',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ==========================================
-- TABLE 2: customers (Main Entity)
-- ==========================================
CREATE TABLE IF NOT EXISTS customers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100),
    phone VARCHAR(20),
    address TEXT,
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
);

-- ==========================================
-- TABLE 3: orders (Transaction Table)
-- ==========================================
CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT NOT NULL,
    user_id INT NOT NULL,
    product VARCHAR(100) NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    status ENUM('pending','processing','completed','cancelled') DEFAULT 'pending',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ==========================================
-- SEED DATA: Default admin user
-- Password: admin123 (hashed)
-- ==========================================
INSERT INTO users (username, full_name, email, password, role) VALUES
('admin', 'System Administrator', 'admin@smartorder.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin'),
('staff1', 'Juan Dela Cruz', 'juan@smartorder.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'staff');

-- Sample customers
INSERT INTO customers (name, email, phone, address, created_by) VALUES
('Maria Santos', 'maria@email.com', '09171234567', '123 Rizal St., Manila', 1),
('Jose Reyes', 'jose@email.com', '09281234567', '456 Mabini Ave., Quezon City', 1),
('Ana Garcia', 'ana@email.com', '09391234567', '789 Bonifacio Blvd., Makati', 2);

-- Sample orders
INSERT INTO orders (customer_id, user_id, product, quantity, price, status, notes) VALUES
(1, 1, 'Office Chair', 2, 3500.00, 'completed', 'Delivered on time'),
(1, 2, 'Laptop Stand', 1, 850.00, 'processing', ''),
(2, 1, 'Mechanical Keyboard', 3, 2200.00, 'pending', 'Customer requested blue switches'),
(3, 2, 'USB Hub', 5, 450.00, 'completed', ''),
(2, 1, 'Monitor', 1, 12000.00, 'processing', '27 inch preferred');
