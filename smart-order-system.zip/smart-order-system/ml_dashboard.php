<?php
// ml_dashboard.php
require_once 'includes/session_check.php';
require_once 'config/Database.php';
require_once 'classes/MLModel.php';

$db = (new Database())->getConnection();
$ml = new MLModel($db);
$ml->preprocessData();
$ml->trainModel();

$summary   = $ml->predict('summary');
$sentiment = $ml->predict('sentiment');

$predictions = $summary['predictions'];
$counts      = $summary['counts'];
$avgScore    = $summary['avg_score'];

// Split predictions into groups for display
$veryLikely = array_values(array_filter($predictions, fn($p) => $p['label'] === 'Very Likely'));
$likely     = array_values(array_filter($predictions, fn($p) => $p['label'] === 'Likely'));
$uncertain  = array_values(array_filter($predictions, fn($p) => $p['label'] === 'Uncertain'));
$unlikely   = array_values(array_filter($predictions, fn($p) => $p['label'] === 'Unlikely'));
$noOrders   = array_values(array_filter($predictions, fn($p) => $p['label'] === 'No Orders'));

$pageTitle  = 'ML Insights — Order Prediction';
$activePage = 'ml';
include 'includes/header.php';
?>

<!-- ══ HERO ══════════════════════════════════ -->
<div class="ml-hero">
  <div class="ml-hero-dot-grid"></div>
  <div class="ml-hero-glow"></div>
  <div class="ml-hero-body">
    <div class="ml-hero-icon"><i class="bi bi-cpu-fill"></i></div>
    <div class="ml-hero-text">
      <h2 class="ml-hero-title">Order Prediction</h2>
      <p class="ml-hero-sub">
        Predicts whether each customer will place another order using a
        5-feature weighted model — Frequency, Loyalty, Recency, Spend &amp; Cancellation rate.
        Order notes are analysed with <code>davmixcool/php-sentiment-analyzer</code> (VADER).
      </p>
    </div>
    <div class="ml-hero-avg">
      <div class="ml-hero-avg-val"><?= $avgScore ?>%</div>
      <div class="ml-hero-avg-label">Avg. likelihood<br>across all customers</div>
    </div>
  </div>
</div>

<!-- ══ SUMMARY CHIPS ═════════════════════════ -->
<div class="ml-chips">
  <div class="ml-chip green">
    <i class="bi bi-arrow-repeat"></i>
    <span class="ml-chip-n"><?= $counts['Very Likely'] ?></span>
    <span class="ml-chip-l">Very Likely</span>
  </div>
  <div class="ml-chip blue">
    <i class="bi bi-clock-history"></i>
    <span class="ml-chip-n"><?= $counts['Likely'] ?></span>
    <span class="ml-chip-l">Likely</span>
  </div>
  <div class="ml-chip amber">
    <i class="bi bi-exclamation-circle"></i>
    <span class="ml-chip-n"><?= $counts['Uncertain'] ?></span>
    <span class="ml-chip-l">Uncertain</span>
  </div>
  <div class="ml-chip red">
    <i class="bi bi-x-circle"></i>
    <span class="ml-chip-n"><?= $counts['Unlikely'] ?></span>
    <span class="ml-chip-l">Unlikely</span>
  </div>
  <div class="ml-chip muted">
    <i class="bi bi-dash-circle"></i>
    <span class="ml-chip-n"><?= $counts['No Orders'] ?></span>
    <span class="ml-chip-l">No Orders</span>
  </div>
</div>

<!-- ══ HOW IT WORKS ══════════════════════════ -->
<div class="ml-how">
  <div class="ml-how-title">
    <i class="bi bi-diagram-2-fill"></i> How the Model Works
    <span class="ml-tag">Weighted Scoring Algorithm</span>
  </div>
  <div class="ml-how-features">
    <?php
    $features = [
      ['frequency', 'bi-bar-chart-fill',    'Frequency',         '30%', 'How many orders the customer has placed relative to the highest in the dataset.', 'blue'],
      ['loyalty',   'bi-patch-check-fill',  'Loyalty',           '25%', 'Completion rate — completed orders ÷ total orders × 100.', 'green'],
      ['recency',   'bi-calendar-check',    'Recency',           '25%', 'How recently the customer last ordered. Score decays the longer they\'ve been inactive.', 'amber'],
      ['spend',     'bi-cash-coin',         'Spend',             '15%', 'Total spend relative to the highest-spending customer in the dataset.', 'red'],
      ['cancel_pen','bi-slash-circle',      'Cancel Penalty',    '5%',  'Subtracted from the score based on the proportion of cancelled orders.', 'muted'],
    ];
    foreach ($features as [$key, $icon, $label, $weight, $desc, $color]):
    ?>
    <div class="ml-feature-block">
      <div class="ml-feature-icon <?= $color ?>"><i class="bi <?= $icon ?>"></i></div>
      <div class="ml-feature-info">
        <div class="ml-feature-name"><?= $label ?> <span class="ml-feature-weight"><?= $weight ?></span></div>
        <div class="ml-feature-desc"><?= $desc ?></div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</div>

<!-- ══ FULL PREDICTION TABLE ═════════════════ -->
<div class="ml-section-title">
  <i class="bi bi-table"></i> All Customer Predictions
</div>

<?php if (empty($predictions)): ?>
  <div class="ml-card">
    <div class="empty-state">
      <i class="bi bi-people"></i>
      <p>No customers found. <a href="customers_add.php">Add a customer</a> to begin predicting.</p>
    </div>
  </div>
<?php else: ?>
<div class="ml-card">
  <div class="ml-table-scroll">
  <table class="ml-table">
    <thead>
      <tr>
        <th>Customer</th>
        <th>Orders</th>
        <th>Last Order</th>
        <th>Completed</th>
        <th>Cancelled</th>
        <th>Total Spent</th>
        <th>Likelihood</th>
        <th>Prediction</th>
        <th>Advice</th>
      </tr>
    </thead>
    <tbody>
    <?php foreach ($predictions as $p): ?>
      <tr class="ml-row-<?= $p['color'] ?>">
        <td>
          <div class="ml-cust-name"><?= htmlspecialchars($p['name']) ?></div>
          <?php if ($p['email']): ?>
          <div class="ml-cust-email"><?= htmlspecialchars($p['email']) ?></div>
          <?php endif; ?>
        </td>
        <td class="ml-num"><?= $p['order_count'] ?></td>
        <td class="ml-muted"><?= $p['days_since'] !== null ? $p['days_since'].'d ago' : '—' ?></td>
        <td class="ml-num"><?= $p['completed'] ?></td>
        <td class="ml-num"><?= $p['cancelled'] ?></td>
        <td class="ml-num">₱<?= number_format($p['total_spent'], 0) ?></td>
        <td style="min-width:120px">
          <?php if ($p['score'] > 0): ?>
          <div class="ml-bar-wrap">
            <div class="ml-bar ml-bar-<?= $p['color'] ?>" style="width:<?= $p['score'] ?>%"></div>
          </div>
          <span class="ml-bar-pct"><?= $p['score'] ?>%</span>
          <?php else: ?>
          <span class="ml-muted">—</span>
          <?php endif; ?>
        </td>
        <td>
          <span class="ml-badge ml-badge-<?= $p['color'] ?>">
            <i class="bi <?= $p['icon'] ?>"></i>
            <?= $p['label'] ?>
          </span>
        </td>
        <td class="ml-advice"><?= htmlspecialchars($p['advice']) ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  </div>
</div>

<!-- ══ FEATURE BREAKDOWN (expandable per customer) ═══════ -->
<div class="ml-section-title" style="margin-top:28px">
  <i class="bi bi-sliders2"></i> Feature Score Breakdown
  <span class="ml-tag">Per Customer</span>
</div>

<div class="row g-3">
<?php foreach (array_filter($predictions, fn($p) => $p['score'] > 0) as $p): ?>
<div class="col-sm-6 col-xl-4">
  <div class="ml-breakdown-card">
    <div class="ml-bd-header">
      <span class="ml-bd-name"><?= htmlspecialchars($p['name']) ?></span>
      <span class="ml-badge ml-badge-<?= $p['color'] ?>">
        <i class="bi <?= $p['icon'] ?>"></i><?= $p['label'] ?>
      </span>
    </div>
    <div class="ml-bd-score-row">
      <span class="ml-bd-score-num"><?= $p['score'] ?>%</span>
      <span class="ml-bd-score-label">prediction score</span>
    </div>
    <?php
    $featureMeta = [
      'frequency'  => ['Frequency',      'blue',  'bi-bar-chart-fill'],
      'loyalty'    => ['Loyalty',         'green', 'bi-patch-check-fill'],
      'recency'    => ['Recency',         'amber', 'bi-calendar-check'],
      'spend'      => ['Spend',           'red',   'bi-cash-coin'],
      'cancel_pen' => ['Cancel Penalty',  'muted', 'bi-slash-circle'],
    ];
    foreach ($p['features'] as $key => $val):
      [$fname, $fcolor, $ficon] = $featureMeta[$key];
    ?>
    <div class="ml-bd-row">
      <div class="ml-bd-feat">
        <i class="bi <?= $ficon ?> ml-bd-feat-icon <?= $fcolor ?>"></i>
        <span><?= $fname ?></span>
      </div>
      <div class="ml-bd-bar-wrap">
        <div class="ml-bd-bar ml-bar-<?= $fcolor ?>" style="width:<?= max($val, 2) ?>%"></div>
      </div>
      <span class="ml-bd-val"><?= $val ?>%</span>
    </div>
    <?php endforeach; ?>
  </div>
</div>
<?php endforeach; ?>
</div>
<?php endif; ?>

<!-- ══ SENTIMENT ANALYSIS ════════════════════ -->
<div class="ml-section-title" style="margin-top:28px">
  <i class="bi bi-chat-heart-fill"></i> Order Note Sentiment
  <span class="ml-tag">VADER · davmixcool/php-sentiment-analyzer</span>
</div>

<div class="row g-3 mb-3">
  <div class="col-sm-4">
    <div class="ml-sent-stat green">
      <div class="ml-sent-val"><?= $sentiment['avgPos'] ?>%</div>
      <div class="ml-sent-label"><i class="bi bi-emoji-smile-fill"></i> Average Positive</div>
    </div>
  </div>
  <div class="col-sm-4">
    <div class="ml-sent-stat red">
      <div class="ml-sent-val"><?= $sentiment['avgNeg'] ?>%</div>
      <div class="ml-sent-label"><i class="bi bi-emoji-frown-fill"></i> Average Negative</div>
    </div>
  </div>
  <div class="col-sm-4">
    <div class="ml-sent-stat <?= $sentiment['overallColor'] ?>">
      <div class="ml-sent-val"><?= $sentiment['overall'] ?></div>
      <div class="ml-sent-label"><i class="bi bi-emoji-neutral-fill"></i> Overall Sentiment</div>
    </div>
  </div>
</div>

<?php if (empty($sentiment['rows'])): ?>
<div class="ml-card">
  <div class="empty-state">
    <i class="bi bi-chat-slash"></i>
    <p>No order notes available. Add notes when creating orders to see sentiment analysis here.</p>
  </div>
</div>
<?php else: ?>
<div class="ml-card">
  <div class="ml-table-scroll">
  <table class="ml-table">
    <thead>
      <tr>
        <th>Customer</th>
        <th>Product</th>
        <th>Note</th>
        <th>Positive</th>
        <th>Negative</th>
        <th>Neutral</th>
        <th>Sentiment</th>
      </tr>
    </thead>
    <tbody>
    <?php foreach ($sentiment['rows'] as $s): ?>
    <tr>
      <td class="ml-cust-name"><?= htmlspecialchars($s['customer_name']) ?></td>
      <td class="ml-muted"><?= htmlspecialchars($s['product']) ?></td>
      <td style="max-width:200px">
        <div class="ml-note-text"><?= htmlspecialchars($s['note']) ?></div>
      </td>
      <td><span class="ml-sent-pct green"><?= $s['pos'] ?>%</span></td>
      <td><span class="ml-sent-pct red"><?= $s['neg'] ?>%</span></td>
      <td><span class="ml-sent-pct amber"><?= $s['neu'] ?>%</span></td>
      <td>
        <span class="ml-badge ml-badge-<?= $s['color'] ?>">
          <i class="bi <?= $s['icon'] ?>"></i>
          <?= $s['label'] ?>
        </span>
      </td>
    </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  </div>
</div>
<?php endif; ?>

<?php include 'includes/footer.php'; ?>
