<?php
// includes/header.php
// $pageTitle must be set before including this file
$pageTitle = $pageTitle ?? 'Smart Order System';
$activePage = $activePage ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($pageTitle) ?> — Smart Order System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link href="<?= $cssPath ?? '' ?>assets/style.css" rel="stylesheet">
</head>
<body>

<!-- Sidebar -->
<div class="wrapper d-flex">
    <nav id="sidebar">
        <div class="sidebar-header">
            <div class="brand-icon"><i class="bi bi-box-seam-fill"></i></div>
            <div>
                <div class="brand-name">SmartOrder</div>
                <div class="brand-sub">Management System</div>
            </div>
        </div>

        <ul class="sidebar-nav">
            <li>
                <a href="<?= $cssPath ?? '' ?>dashboard.php" class="<?= $activePage==='dashboard' ? 'active' : '' ?>">
                    <i class="bi bi-speedometer2"></i> Dashboard
                </a>
            </li>
            <li>
                <a href="<?= $cssPath ?? '' ?>customers.php" class="<?= $activePage==='customers' ? 'active' : '' ?>">
                    <i class="bi bi-people-fill"></i> Customers
                </a>
            </li>
            <li>
                <a href="<?= $cssPath ?? '' ?>orders.php" class="<?= $activePage==='orders' ? 'active' : '' ?>">
                    <i class="bi bi-cart-fill"></i> Orders
                </a>
            </li>
            <li>
                <a href="<?= $cssPath ?? '' ?>reports.php" class="<?= $activePage==='reports' ? 'active' : '' ?>">
                    <i class="bi bi-bar-chart-fill"></i> Reports
                </a>
            </li>
            <?php if (Auth::isAdmin()): ?>
            <li>
                <a href="<?= $cssPath ?? '' ?>users.php" class="<?= $activePage==='users' ? 'active' : '' ?>">
                    <i class="bi bi-shield-person-fill"></i> Users
                </a>
            </li>
            <?php endif; ?>
            <li class="mt-auto">
                <a href="<?= $cssPath ?? '' ?>about.php" class="<?= $activePage==='about' ? 'active' : '' ?>">
                    <i class="bi bi-info-circle-fill"></i> About
                </a>
            </li>
            <li>
                <a href="<?= $cssPath ?? '' ?>developers.php" class="<?= $activePage==='developers' ? 'active' : '' ?>">
                    <i class="bi bi-code-slash"></i> Developers
                </a>
            </li>
        </ul>

        <div class="sidebar-footer">
            <div class="user-info">
                <div class="user-avatar"><i class="bi bi-person-fill"></i></div>
                <div>
                    <div class="user-name"><?= htmlspecialchars($currentUser['full_name']) ?></div>
                    <div class="user-role"><?= ucfirst(htmlspecialchars($currentUser['role'])) ?></div>
                </div>
            </div>
            <a href="<?= $cssPath ?? '' ?>logout.php" class="logout-btn" title="Logout">
                <i class="bi bi-box-arrow-right"></i>
            </a>
        </div>
    </nav>

    <!-- Main Content -->
    <div id="main-content">
        <!-- Top bar -->
        <div class="topbar">
            <button class="sidebar-toggle" id="sidebarToggle">
                <i class="bi bi-list"></i>
            </button>
            <div class="topbar-title"><?= htmlspecialchars($pageTitle) ?></div>
            <div class="topbar-right">
                <span class="badge-role <?= $currentUser['role'] === 'admin' ? 'badge-admin' : 'badge-staff' ?>">
                    <i class="bi bi-circle-fill"></i>
                    <?= ucfirst(htmlspecialchars($currentUser['role'])) ?>
                </span>
            </div>
        </div>
        <div class="page-content">
