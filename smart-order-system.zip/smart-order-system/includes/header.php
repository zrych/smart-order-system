<?php
// includes/header.php
$pageTitle  = $pageTitle  ?? 'Smart Order System';
$activePage = $activePage ?? '';
$cssPath    = $cssPath    ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= htmlspecialchars($pageTitle) ?> — SmartOrder</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <link href="<?= $cssPath ?>assets/style.css" rel="stylesheet">
</head>
<body>

<!-- ── Mobile backdrop ─────────────────────── -->
<div id="backdrop"></div>

<!-- ── Sidebar ─────────────────────────────── -->
<nav id="sidebar" role="navigation" aria-label="Main navigation">

  <div class="sb-header">
    <div class="sb-logo"><i class="bi bi-box-seam-fill"></i></div>
    <div class="sb-brand">
      <div class="sb-brand-name">SmartOrder</div>
      <div class="sb-brand-sub">Management System</div>
    </div>
  </div>

  <ul class="sb-nav" role="list">
    <li>
      <a class="sb-link <?= $activePage==='dashboard' ? 'active':'' ?>"
         href="<?= $cssPath ?>dashboard.php">
        <i class="bi bi-speedometer2 sb-icon"></i>Dashboard
      </a>
    </li>
    <li>
      <a class="sb-link <?= $activePage==='customers' ? 'active':'' ?>"
         href="<?= $cssPath ?>customers.php">
        <i class="bi bi-people-fill sb-icon"></i>Customers
      </a>
    </li>
    <li>
      <a class="sb-link <?= $activePage==='orders' ? 'active':'' ?>"
         href="<?= $cssPath ?>orders.php">
        <i class="bi bi-cart-fill sb-icon"></i>Orders
      </a>
    </li>
    <li>
      <a class="sb-link <?= $activePage==='reports' ? 'active':'' ?>"
         href="<?= $cssPath ?>reports.php">
        <i class="bi bi-bar-chart-fill sb-icon"></i>Reports
      </a>
    </li>
    <?php if (Auth::isAdmin()): ?>
    <li>
      <a class="sb-link <?= $activePage==='users' ? 'active':'' ?>"
         href="<?= $cssPath ?>users.php">
        <i class="bi bi-shield-person-fill sb-icon"></i>Users
      </a>
    </li>
    <?php endif; ?>

    <li><div class="sb-divider" role="separator"></div></li>

    <li>
      <a class="sb-link <?= $activePage==='about' ? 'active':'' ?>"
         href="<?= $cssPath ?>about.php">
        <i class="bi bi-info-circle-fill sb-icon"></i>About
      </a>
    </li>
    <li>
      <a class="sb-link <?= $activePage==='developers' ? 'active':'' ?>"
         href="<?= $cssPath ?>developers.php">
        <i class="bi bi-code-slash sb-icon"></i>Developers
      </a>
    </li>
  </ul>

  <div class="sb-footer">
    <div class="sb-user">
      <div class="sb-avatar">
        <?= strtoupper(substr($currentUser['full_name'], 0, 1)) ?>
      </div>
      <div>
        <div class="sb-uname"><?= htmlspecialchars($currentUser['full_name']) ?></div>
        <div class="sb-urole"><?= ucfirst($currentUser['role']) ?></div>
      </div>
    </div>
    <a href="<?= $cssPath ?>logout.php" class="sb-logout" title="Logout">
      <i class="bi bi-box-arrow-right"></i>
    </a>
  </div>

</nav>

<!-- ── Main content ─────────────────────────── -->
<div id="main-content">

  <header class="topbar">
    <!-- Hamburger: only visible on mobile via CSS -->
    <button class="hamburger" id="menuBtn" aria-label="Open menu" aria-expanded="false" aria-controls="sidebar">
      <i class="bi bi-list"></i>
    </button>

    <span class="topbar-title"><?= htmlspecialchars($pageTitle) ?></span>

    <div class="topbar-right">
      <span class="role-chip <?= $currentUser['role']==='admin' ? 'role-admin' : 'role-staff' ?>">
        <i class="bi bi-circle-fill"></i>
        <?= ucfirst($currentUser['role']) ?>
      </span>
    </div>
  </header>

  <div class="page-content">
