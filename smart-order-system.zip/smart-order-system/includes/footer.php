  </div><!-- /.page-content -->
</div><!-- /#main-content -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
(function () {
  'use strict';

  var sidebar  = document.getElementById('sidebar');
  var backdrop = document.getElementById('backdrop');
  var menuBtn  = document.getElementById('menuBtn');

  // Only wire up the overlay behaviour on mobile.
  // On desktop (≥768px) the sidebar is always visible via CSS —
  // no JavaScript needed for it at all.
  function isMobile() {
    return window.matchMedia('(max-width: 767px)').matches;
  }

  function openMenu() {
    sidebar.classList.add('sidebar-open');
    backdrop.classList.add('show');
    menuBtn.setAttribute('aria-expanded', 'true');
    document.body.style.overflow = 'hidden';
  }

  function closeMenu() {
    sidebar.classList.remove('sidebar-open');
    backdrop.classList.remove('show');
    menuBtn.setAttribute('aria-expanded', 'false');
    document.body.style.overflow = '';
  }

  if (menuBtn) {
    menuBtn.addEventListener('click', function () {
      if (isMobile()) {
        sidebar.classList.contains('sidebar-open') ? closeMenu() : openMenu();
      }
    });
  }

  if (backdrop) {
    backdrop.addEventListener('click', function () {
      if (isMobile()) closeMenu();
    });
  }

  // Close on ESC
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && isMobile()) closeMenu();
  });

  // On resize to desktop: clean up any leftover mobile state
  window.addEventListener('resize', function () {
    if (!isMobile()) {
      sidebar.classList.remove('sidebar-open');
      backdrop.classList.remove('show');
      document.body.style.overflow = '';
    }
  });

  // Auto-dismiss flash alerts after 4 s
  setTimeout(function () {
    document.querySelectorAll('.alert-auto-dismiss').forEach(function (el) {
      var bsAlert = bootstrap.Alert.getOrCreateInstance(el);
      bsAlert.close();
    });
  }, 4000);

}());
</script>
</body>
</html>
