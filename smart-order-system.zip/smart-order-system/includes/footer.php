        </div><!-- end page-content -->
    </div><!-- end main-content -->
</div><!-- end wrapper -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Sidebar toggle
    document.getElementById('sidebarToggle').addEventListener('click', function () {
        document.getElementById('sidebar').classList.toggle('collapsed');
        document.getElementById('main-content').classList.toggle('expanded');
    });

    // Auto-dismiss alerts after 4 seconds
    setTimeout(function () {
        const alerts = document.querySelectorAll('.alert-auto-dismiss');
        alerts.forEach(a => {
            const bsAlert = new bootstrap.Alert(a);
            bsAlert.close();
        });
    }, 4000);
</script>
</body>
</html>
