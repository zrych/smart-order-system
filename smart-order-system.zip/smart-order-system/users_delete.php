<?php
// users_delete.php
require_once 'includes/session_check.php';
if (!Auth::isAdmin()) { header('Location: dashboard.php'); exit(); }
require_once 'config/Database.php';
require_once 'classes/User.php';

$db   = (new Database())->getConnection();
$user = new User($db);

$id = (int)($_GET['id'] ?? 0);

// Prevent self-deletion
if ($id && $id !== (int)$currentUser['id']) {
    $user->delete($id);
}
header('Location: users.php?success=deleted');
exit();
